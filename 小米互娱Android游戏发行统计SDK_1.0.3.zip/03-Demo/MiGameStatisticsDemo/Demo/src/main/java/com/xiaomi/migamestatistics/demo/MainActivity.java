package com.xiaomi.migamestatistics.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.xiaomi.migamechannel.MiGameChannel;
import com.xiaomi.migamechannel.MiGameStatistics;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private final String MiGame_AppId = "12345678";

    private EditText roleIdEdit, roleLevelEdit, priceEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        resultToast(MiGameStatistics.Initialize(this, MiGame_AppId, MiGameChannel.XiaoMi), "Initialize");
    }

    @Override
    protected void onResume() {
        super.onResume();
        resultToast(MiGameStatistics.onResume(), "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        resultToast(MiGameStatistics.onPause(), "onPause");
    }

    private void initView() {
        roleIdEdit = (EditText) findViewById(R.id.role_id);
        roleLevelEdit = (EditText) findViewById(R.id.role_level);
        priceEdit = (EditText) findViewById(R.id.price);

        findViewById(R.id.register).setOnClickListener(this);
        findViewById(R.id.login).setOnClickListener(this);
        findViewById(R.id.level_up).setOnClickListener(this);
        findViewById(R.id.before_recharge).setOnClickListener(this);
        findViewById(R.id.after_recharge).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String roleId = roleIdEdit.getText().toString();
        String roleLevel = roleLevelEdit.getText().toString();
        String price = priceEdit.getText().toString();
        switch (v.getId()) {
            case R.id.register:
                resultToast(MiGameStatistics.Register(roleId, roleLevel), "Register");
                break;
            case R.id.login:
                resultToast(MiGameStatistics.Login(roleId, roleLevel), "Login");
                break;
            case R.id.level_up:
                resultToast(MiGameStatistics.RoleLevelUpgrade(roleId, roleLevel), "Level Up");
                break;
            case R.id.before_recharge:
                resultToast(MiGameStatistics.BeforeRecharge(roleId, roleLevel, price), "Before Recharge");
                break;
            case R.id.after_recharge:
                resultToast(MiGameStatistics.AfterRecharge(roleId, roleLevel, price), "After Recharge");
                break;
        }
    }

    private void resultToast(boolean result, String toast) {
        if (result) {
            Toast.makeText(this, toast, Toast.LENGTH_SHORT).show();
        }
    }
}
