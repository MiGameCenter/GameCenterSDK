
package com.example.migamechanneldemo;

import com.xiaomi.migamechannel.MiGameChannel;
import com.xiaomi.migamechannel.MiGameStatistics;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class DemoActivity extends Activity {
    EditText loginId, loginLevel,
            beforeId, beforeLevel, beforePrice,
            successId, successLevel, successPrice,
            levelUpId, levelUpLevel;
    Button loginBtn, beforeBtn, successBtn, levelUpBtn, startBtn, endBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);
        initView();
        initClick();
        MiGameStatistics.Initialize(getApplicationContext(), "12345678", MiGameChannel.XiaoMi);
    }

    private void initView() {
        loginId = (EditText) findViewById(R.id.hd_user_id);
        loginLevel = (EditText) findViewById(R.id.hd_user_l);
        beforeId = (EditText) findViewById(R.id.pay_b_id);
        beforeLevel = (EditText) findViewById(R.id.pay_b_l);
        beforePrice = (EditText) findViewById(R.id.pay_b_m);
        successId = (EditText) findViewById(R.id.pay_a_id);
        successLevel = (EditText) findViewById(R.id.pay_a_l);
        successPrice = (EditText) findViewById(R.id.pay_a_m);
        levelUpId = (EditText) findViewById(R.id.level_id);
        levelUpLevel = (EditText) findViewById(R.id.level_l);

        loginBtn = (Button) findViewById(R.id.hd_login);
        beforeBtn = (Button) findViewById(R.id.pay_b_btn);
        successBtn = (Button) findViewById(R.id.pay_a_s);
        levelUpBtn = (Button) findViewById(R.id.level_btn);
        startBtn = (Button) findViewById(R.id.time_btn);
        endBtn = (Button) findViewById(R.id.ti_btn);
    }

    private void initClick() {
        loginBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                MiGameStatistics.Login(loginId.getText().toString(), loginLevel.getText().toString());
            }
        });
        beforeBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                MiGameStatistics.BeforeRecharge(beforeId.getText().toString(), beforeLevel.getText().toString(), beforePrice
                        .getText().toString());
            }
        });
        successBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                MiGameStatistics.AfterRecharge(successId.getText().toString(), successLevel.getText().toString(), successPrice
                        .getText().toString());
            }
        });
        levelUpBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                MiGameStatistics.RoleLevelUpgrade(levelUpId.getText().toString(), levelUpLevel.getText().toString());
            }
        });
        startBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                MiGameStatistics.setForegroundTime();
            }
        });
        endBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                MiGameStatistics.UploadDuration();
            }
        });
    }
}
