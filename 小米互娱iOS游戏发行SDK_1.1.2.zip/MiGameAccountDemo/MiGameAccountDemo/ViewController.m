//
//  ViewController.m
//  MiGameAdPlatformDemo
//
//  Created by 张朝杰 on 15/10/16.
//  Copyright (c) 2015年 zhangchaojie. All rights reserved.
//
#import "ViewController.h"
#import <MiGameSDK/MiGameSDK.h>

@interface ViewController () <MiGameAccountDelegate>
@property(nonatomic, strong, readwrite) MiGameAccount *miGameAccount;
@end

@implementation ViewController {
    IBOutlet UILabel *mStateLabel;
    IBOutlet UIButton *mLoginBtn;
    IBOutlet UIButton *mCurAccountBtn;
    IBOutlet UIButton *mSwitchAccountBtn;
    IBOutlet UIButton *mBindAccountBtn;
    IBOutlet UIButton *mChangePasswordBtn;
    IBOutlet UIButton *mLogoutBtn;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.miGameAccount = [[MiGameAccount alloc] initWithAppId:@"12345678" andDelegate:self];
    mStateLabel.text = @"未登录";
    mBindAccountBtn.enabled = NO;
    mChangePasswordBtn.enabled = NO;
    mLogoutBtn.enabled = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UI Button Event

- (IBAction)onCurAccountBtnClick:(id)sender {
    //查看当前账号
    NSString *accountState;
    MiGameAccountState state = [self.miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    mStateLabel.text = accountState;
}

- (IBAction)onLoginBtnClick:(id)sender {
    //登录操作
    [self.miGameAccount miLogin];
}

- (IBAction)onSwitchAccountBtnClick:(id)sender {
    //切换帐户操作
    [self.miGameAccount miSwitchAccount];
}

- (IBAction)onBindAccountBtnClick:(id)sender {
    //游客帐户绑定成小米帐户
    [self.miGameAccount miBindAccount];
}

- (IBAction)onChangePasswordBtnClick:(id)sender {
    //修改小米帐户密码
    [self.miGameAccount miChangePassword];
}

- (IBAction)onLogoutBtnClick:(id)sender {
    //清空小米帐户信息
    [self.miGameAccount miLogout];

    mStateLabel.text = @"未登录";
    mBindAccountBtn.enabled = NO;
    mChangePasswordBtn.enabled = NO;
    mLogoutBtn.enabled = NO;
}


#pragma mark - MiGameAccountDelegate

/**
 * Called when the user successfully logged in.
 */
- (void)loginFinished:(MiGameAccount *)miGameAccount GameUId:(NSString *)gameUid {
    NSString *accountState;
    MiGameAccountState state = [miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    NSLog(@"登录成功 accountState=%@ gameUid:%@", accountState, gameUid);
    mStateLabel.text = [NSString stringWithFormat:@"登录成功 %@ gameUid:%@", accountState, gameUid];
    mBindAccountBtn.enabled = (state == MiGameAccount_Login_Guest);
    mChangePasswordBtn.enabled = (state == MiGameAccount_Login_Mi);
    mLogoutBtn.enabled = (state == MiGameAccount_Login_Mi);
}

/**
 * Called when the user cancelde to log in.
 */
- (void)loginCanceled:(MiGameAccount *)miGameAccount {
    NSString *accountState;
    MiGameAccountState state = [miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    NSLog(@"登录取消 accountState=%@", accountState);
    mStateLabel.text = [NSString stringWithFormat:@"登录取消 %@", accountState];
}

/**
 * Called when the user failed to log in.
 */
- (void)loginFailed:(MiGameAccount *)miGameAccount failedWithError:(NSError *)error {
    NSString *accountState;
    MiGameAccountState state = [miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    NSLog(@"登录失败 accountState=%@ errorCode=%d userInfo=%@ localizedDescription=%@", accountState, (int) [error code], [error userInfo], [error localizedDescription]);
    mStateLabel.text = [NSString stringWithFormat:@"登录失败 %@ 错误码=%d", accountState, (int) [error code]];
}


/**
 * Called when the user successfully bind.
 */
- (void)bindFinished:(MiGameAccount *)miGameAccount GameUId:(NSString *)gameUid {
    NSString *accountState;
    MiGameAccountState state = [miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    NSLog(@"绑定成功 accountState=%@ gameUid:%@", accountState, gameUid);
    mStateLabel.text = [NSString stringWithFormat:@"绑定成功 %@ gameUid:%@", accountState, gameUid];
    mBindAccountBtn.enabled = (state == MiGameAccount_Login_Guest);
    mChangePasswordBtn.enabled = (state == MiGameAccount_Login_Mi);
    mLogoutBtn.enabled = (state == MiGameAccount_Login_Mi);
}

/**
 * Called when the user canceled to bind.
 */
- (void)bindCanceled:(MiGameAccount *)miGameAccount {
    NSString *accountState;
    MiGameAccountState state = [miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    NSLog(@"绑定取消 accountState=%@", accountState);
    mStateLabel.text = [NSString stringWithFormat:@"绑定取消 %@", accountState];
}

/**
 * Called when the user failed to bind.
 */
- (void)bindFailed:(MiGameAccount *)miGameAccount failedWithError:(NSError *)error {
    NSString *accountState;
    MiGameAccountState state = [miGameAccount curAccountState];
    switch (state) {
        case MiGameAccount_Login_Mi:
            accountState = @"小米帐户";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"游客模式";
            break;
        default:
            accountState = @"未登录";
            break;
    }
    NSLog(@"绑定失败 accountState=%@ errorCode=%d userInfo=%@ localizedDescription=%@", accountState, (int) [error code], [error userInfo], [error localizedDescription]);
    mStateLabel.text = [NSString stringWithFormat:@"绑定失败 %@ 错误码=%d", accountState, (int) [error code]];
}

@end
