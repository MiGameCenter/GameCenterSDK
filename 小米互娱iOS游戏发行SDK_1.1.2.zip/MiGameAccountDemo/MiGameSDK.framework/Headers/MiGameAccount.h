//
//  MiGameAccount.h
//  MiGameSDK
//
//  Created by 张朝杰 on 15/10/15.
//  Copyright (c) 2015年 XiaoMi. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MiGameAccountDelegate;

/*
 * 登录状态
 */
typedef enum {
    MiGameAccount_Logout = 0,
    MiGameAccount_Login_Guest = 1,
    MiGameAccount_Login_Mi = 2,
} MiGameAccountState;

@interface MiGameAccount : NSObject

@property(nonatomic, weak) id <MiGameAccountDelegate> miDelegate;

/**
 * Initialize a MiGameAccount with AppId and AppKey
 *
 */
- (id)initWithAppId:(NSString *)appId
        andDelegate:(id <MiGameAccountDelegate>)delegate;

/**
 * 登录，异步操作，回调 MiGameAccountDelegate
 */
- (void)miLogin;

/**
 * 当前用户帐户身份
 */
- (MiGameAccountState)curAccountState;

/**
 * 绑定帐户，弹出界面（游客身份生效）
 */
- (void)miBindAccount;

/**
 * 切换帐户，弹出界面
 */
- (void)miSwitchAccount;

/**
 * 修改小米帐户密码(小米帐户生效)
 */
- (void)miChangePassword;

/**
 * 登出操作(游客身份登出无效)
 */
- (BOOL)miLogout;

@end

#pragma mark - MiGameAccountDelegate

@protocol MiGameAccountDelegate <NSObject>

@optional

/**
 * Called when the user successfully logged in.
 */
- (void)loginFinished:(MiGameAccount *)miGameAccount GameUId:(NSString *)gameUid;

/**
 * Called when the user canceled to log in.
 */
- (void)loginCanceled:(MiGameAccount *)miGameAccount;

/**
 * Called when the user failed to log in.
 */
- (void)loginFailed:(MiGameAccount *)miGameAccount failedWithError:(NSError *)error;

/**
 * Called when the user successfully bind.
 */
- (void)bindFinished:(MiGameAccount *)miGameAccount GameUId:(NSString *)gameUid;

/**
 * Called when the user canceled to bind.
 */
- (void)bindCanceled:(MiGameAccount *)miGameAccount;

/**
 * Called when the user failed to bind.
 */
- (void)bindFailed:(MiGameAccount *)miGameAccount failedWithError:(NSError *)error;

@end

