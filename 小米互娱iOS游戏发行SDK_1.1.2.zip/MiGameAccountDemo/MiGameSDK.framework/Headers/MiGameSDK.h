//
//  MiGameSDK.h
//  MiGameSDK
//
//  Created by 张朝杰 on 10/15/15.
//  Copyright (c) 2015 XiaoMi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MiGameSDK.
FOUNDATION_EXPORT double MiGameSDKVersionNumber;

//! Project version string for MiGameSDK.
FOUNDATION_EXPORT const unsigned char MiGameSDKVersionString[];

#import <MiGameSDK/MiGameAccount.h>
#import <MiGameSDK/MiGameAdPlatform.h>
#import <MiGameSDK/MiGameStatistics.h>

@interface MiGameSDK : NSObject

+ (NSString *)description;

@end