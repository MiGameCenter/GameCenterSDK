//
//  MiGameStatistics.h
//  MiGameSDK
//
//  Created by 张朝杰 on 15/10/15.
//  Copyright (c) 2015年 XiaoMi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MiGameStatistics : NSObject

/**
 *  Start the statistics with required information of the host game app.
 *
 *  @param gameId       unique id of host game
 *  @param gameVersion  version of host game
 *  @param channel      publish channel of host game
 *
 *  @return YES if setup successfully.
 */
+ (BOOL)setup:(NSString *)gameId
      version:(NSString *)gameVersion
      channel:(NSString *)channel;

/**
 *  Do check point when accountId register
 *
 *  @param accountId    the accountId in the game
 *  @param roleId       the default roleId in the game
 *  @param roleLevel    the default role level that role
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onRegisterWithAccountId:(NSString *)accountId
                         roleId:(NSString *)roleId
                      roleLevel:(NSUInteger)roleLevel;

/**
 *  Do check point when role |roleId| of level |roleLevel| logged in
 *
 *  @param accountId    the accountId in the game
 *  @param roleId       the id or role in the game
 *  @param roleLevel    the level that role
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onLoginWithAccountId:(NSString *)accountId
                      roleId:(NSString *)roleId
                   roleLevel:(NSUInteger)roleLevel;

/**
 *  Do check point when role |roleId| of level |roleLevel| start to pay money of |paymentAmount|
 *
 *  @param accountId    the accountId in the game
 *  @param roleId       the id or role in the game
 *  @param roleLevel    the level that role comes up to
 *  @param paymentAmount payment amount
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onBeforePayForAccountId:(NSString *)accountId
                         roleId:(NSString *)roleId
                      roleLevel:(NSUInteger)roleLevel
                  paymentAmount:(double)paymentAmount;

/**
 *  Do check point when role |roleId| of level |roleLevel| payed the money of |paymentAmount|
 *
 *  @param accountId        the accountId in the game
 *  @param roleId           the id or role in the game
 *  @param roleLevel        the level that role comes up to
 *  @param paymentAmount    payment amount
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onPayedSuccessfullyForAccountId:(NSString *)accountId
                                 roleId:(NSString *)roleId
                              roleLevel:(NSUInteger)roleLevel
                          paymentAmount:(double)paymentAmount;

/**
 *  Do check point when role |roleId| comes to a new level |roleLevel|
 *
 *  @param accountId    the accountId in the game
 *  @param roleId       the id or role in the game
 *  @param roleLevel    the level that role comes up to
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onRoleUpWithAccountId:(NSString *)accountId
                       roleId:(NSString *)roleId
                uptoRoleLevel:(NSUInteger)roleLevel;

@end
