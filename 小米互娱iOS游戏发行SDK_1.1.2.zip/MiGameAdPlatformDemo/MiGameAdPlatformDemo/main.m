//
//  main.m
//  MiGameAdPlatformDemo
//
//  Created by 张朝杰 on 15/10/19.
//  Copyright (c) 2015年 张朝杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
