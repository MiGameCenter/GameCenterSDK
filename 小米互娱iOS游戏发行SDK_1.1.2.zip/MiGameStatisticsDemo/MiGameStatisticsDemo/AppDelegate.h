//
//  AppDelegate.h
//  MiGameStatisticsDemo
//
//  Created by 张朝杰 on 15/10/19.
//  Copyright (c) 2015年 张朝杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

