//
//  ViewController.m
//  MiGameStatisticsDemo
//
//  Created by 张朝杰 on 15/10/15.
//  Copyright (c) 2015年 zhangchaojie. All rights reserved.
//

#import "ViewController.h"
#import <MiGameSDK/MiGameSDK.h>

@interface ViewController ()

- (void)getValue;

@end

@implementation ViewController {
    IBOutlet UIButton *registerBtn;
    IBOutlet UIButton *loginBtn;
    IBOutlet UIButton *beforePayBtn;
    IBOutlet UIButton *paySuccessfullyBtn;
    IBOutlet UIButton *levelUpBtn;
    IBOutlet UITextField *accountIdEdt;
    IBOutlet UITextField *roleIdEdt;
    IBOutlet UITextField *roleLeveleEdt;
    IBOutlet UITextField *paymentEdt;
    NSString *accountId;
    NSString *roleId;
    NSInteger roleLevel;
    double paymentAmount;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    registerBtn.enabled = YES;
    loginBtn.enabled = YES;
    beforePayBtn.enabled = NO;
    paySuccessfullyBtn.enabled = NO;
    levelUpBtn.enabled = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onRegisterBtnClick:(id)sender {
    
    [self getValue];
    [MiGameStatistics onRegisterWithAccoutId:accountId roleId:roleId roleLevel:roleLevel];

    loginBtn.enabled = YES;
    beforePayBtn.enabled = NO;
    paySuccessfullyBtn.enabled = NO;
    levelUpBtn.enabled = NO;

    NSLog(@"@@@@@@@@@@@@@@@@@@@@注册打点@@@@@@@@@@@@@@@@@@@@");
}

- (IBAction)onLoginBtnClick:(id)sender {
    loginBtn.enabled = NO;
    [self getValue];
    [MiGameStatistics onLoginWithAccountId:accountId roleId:roleId roleLevel:roleLevel];
    beforePayBtn.enabled = YES;
    paySuccessfullyBtn.enabled = NO;
    levelUpBtn.enabled = YES;

    NSLog(@"####################登陆打点####################");
}

- (IBAction)onBeforePayBtnClick:(id)sender {
    [self getValue];
    [MiGameStatistics onBeforePayForAccountId:accountId roleId:roleId roleLevel:roleLevel paymentAmount:paymentAmount];
    paySuccessfullyBtn.enabled = YES;
    
    NSLog(@"$$$$$$$$$$$$$$$$$$$$开始支付打点$$$$$$$$$$$$$$$$$$$$");
}

- (IBAction)onPaySuccessfullyBtnClick:(id)sender {
    [self getValue];
    [MiGameStatistics onPayedSuccessfullyForAccountId:accountId roleId:roleId roleLevel:roleLevel paymentAmount:paymentAmount];
    paySuccessfullyBtn.enabled = NO;

    NSLog(@"%%%%%%%%%%%%%%%%%%%%支付成功%%%%%%%%%%%%%%%%%%%%");
}

- (IBAction)onLevelUpBtnClick:(id)sender {
    [self getValue];
    [MiGameStatistics onRoleUpWithAccountId:accountId roleId:roleId uptoRoleLevel:roleLevel];
    
    NSLog(@"&&&&&&&&&&&&&&&&&&&&升级打点&&&&&&&&&&&&&&&&&&&&");
}

- (void)getValue{
    accountId = accountIdEdt.text;
    roleId = roleIdEdt.text;
    roleLevel = [roleLeveleEdt.text intValue];
    paymentAmount = [paymentEdt.text doubleValue];
}

@end
