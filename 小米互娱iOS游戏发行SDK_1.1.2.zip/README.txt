小米互娱iOS游戏发行SDK(1.1.2)
====================

小米互娱游戏发行SDK规范-iOS版
本文档帮助游戏开发商(简称CP)将游戏接入小米互娱iOS游戏发行SDK(简称SDK)。

历史版本信息
//TODO

一 目录结构

SDK目录
	|--MiGameSDKwithoutIDFA/MiGameSDK.framework	//账号SDK、统计SDK(无IDFA)
	|--MiGameSDKwithIDFA/MiGameSDK.framework	//账号SDK、统计SDK(有IDFA)
	|--MiGameSDKwithAD/MiGameSDK.framework		//账号SDK、统计SDK、推广SDK
	|--MiGameBundle.Bundle				//本地化字符串及图片资源包
MiGameAccountDemo					//账号SDKDemo
MiGameStatisticsDemo					//统计SDKDemo
MiGameAdPlatformDemo					//推广SDKDemo
README.MD						//说明文档

二 接入说明

1. 运行环境
	iOS 5.1.1 以上
	Xcode 6.0 以上

2. 接入组合
	MiGameSDKwithoutIDFA/MiGameSDK.framework + MiGameBundle.bundle  : 包含账号SDK和统计SDK，App Store初审时对使用IDFA应用审核较为严格，此组合使用其他方式标识用户。
	MiGameSDKwithIDFA/MiGameSDK.framework + MiGameBundle.bundle     : 包含账号SDK和统计SDK，此组合使用IDFA标识用户。
	MiGameSDKwithAD/MiGameSDK.framework + MiGameBundle.bundle       : 包含账号SDK、统计SDK、推广SDK。

3. 接入方法
	(1)将以上组合中的framework包添加到Build Phases - Link Binary With Libraries，bundle包添加到Copy Bundle Resources。
	(2)额外添加libz.dylib、libsqlite3.dylib、StoreKit.framework到Build Phases - Link Binary With Libraries(如果已添加请忽略)。
	(3)添加"-ObjC"到Build Settings - Other Linker Flags。

三 账号SDK接口说明

MiGameAccount为账号SDK相关类

1. 初始化账号SDK
	- (id)initWithAppId:(NSString* )appId andDelegate:(id<MiGameAccountDelegate>)delegate;
	参数说明 : appId为开发者站中应用的appId,不可为空；delegate为回调接收体，接收用户登陆或绑定等操作。
	返回结果 : MiGameAccount实例对象

2. 游客模式/小米账号登录
- (void) miLogin;
	使用说明 : 没有使用过小米账号登录将以游客模式登录，已使用小米账号登录将以上次登录的小米账号登录。
	结果说明 : 异步操作，通过实现以下三个回调接口处理登录的结果
		登录成功 : - (void)loginFinished:(MiGameAccount *)miGameAccount GameUId:(NSString*)gameUid;
		登录取消 : - (void)loginCanceled:(MiGameAccount *)miGameAccount;
		登录失败 : - (void)loginFailed:(MiGameAccount *)miGameAccount failedWithError:(NSError *)error;
3. 登录/切换小米账号
- (void) miSwitchAccount;
	使用说明 : 弹出注册/登录小米账号界面，注册或登录成功将返回小米账号新建的或已绑定的gameUid，游客模式下的gameUid被覆盖。
	结果说明 : 异步操作，通过实现接口2三个回调接口处理登录的结果。

4. 绑定小米账号
- (void) miBindAccount;
	使用说明 : 弹出注册/绑定小米账号界面，注册或绑定成功将返回小米账号绑定的gameUid，此gameUid与游客模式下的gameUid一致，游客模式下的gmaeUid不会被覆盖。
	结果说明 : 异步操作，通过实现以下三个回调接口处理绑定的结果
		绑定成功 : - (void)bindFinished:(MiGameAccount *)miGameAccount GameUId:(NSString*)gameUid;
		绑定取消 : - (void)bindCanceled:(MiGameAccount *)miGameAccount;
		绑定失败 : - (void)bindFailed:(MiGameAccount *)miGameAccountAccount failedWithError:(NSError *)error;

5. 获取当前账号类型
- (MiGameAccountState) curAccountState;
	使用说明 : 获取当前账号的类型，包括未登录状态、游客模式登录、小米账号登录。
	结果说明 : MiGameAccountState是枚举类型，有MiGameAccount_Logout、MiGameAccount_Login_Guest、MiGameAccount_Login_Mi三个值，对应以上三种状态。

6. 修改小米账号密码
- (void)miChangePassword;
	使用说明 : 跳转到浏览器进行修改小米账号密码操作。

6. 登出小米账号
- (BOOL) miLogout;
	使用说明 : 小米账号登出将清除本地的账号信息，游客模式不可登出。
	结果说明 : 小米账号登出成功返回YES(游客模式登出只会返回NO)。

四 统计SDK接口说明

MiGameStatistics为统计SDK相关类

1. 初始化统计SDK
+ (BOOL)setup:(NSString *)gameId version:(NSString *)gameVersion channel:(NSString *)channel;
	使用说明 : 在 - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions 中调用此方法初始化统计SDK。
	参数说明 :
		gameId		: 游戏唯一标识，使用包名，例如:"com.yourcompany.gamename",不可为空。
		gameVersion	: 游戏版本号，不可为空。
		channel		: 渠道类型，如果在AppStore上架设置为"appstore"，如果在越狱市场上架设置为"jb_channelname"，不可为空。
	结果说明 : 布尔值，成功返回YES。

2. 玩家注册游戏
+ (BOOL)onRegisterWithAccoutId:(NSString *)accountId roleId:(NSString *)roleId roleLevel:(NSUInteger)roleLevel;
	使用说明 : 在玩家注册游戏后调用
	参数说明 :
		accountId 	: 游戏账号ID。
		roleId 		: 游戏中的角色ID。
		roleLevel 	: 游戏中的角色等级。
	结果说明 : 布尔值，成功返回YES。

3. 玩家登陆游戏
+ (BOOL)onLoginWithAccountId:(NSString *)accountId roleId:(NSString *)roleId roleLevel:(NSUInteger)roleLevel;
	使用说明 : 在玩家登陆游戏后调用。
	参数说明 :
		accountId 	: 游戏账号ID。
		roleId 		: 游戏中的角色ID。
		roleLevel 	: 游戏中的角色等级。
	结果说明 : 布尔值，成功返回YES。

4. 玩家支付前
+ (BOOL)onBeforePayForAccountId:(NSString *)accountId roleId:(NSString *)roleId roleLevel:(NSUInteger)roleLevel paymentAmount:(double)paymentAmount;
	使用说明 : 在玩家支付前调用。
	参数说明 :
		accountId	: 游戏账号ID。
		roleId		: 游戏中的角色ID。
		roleLevel	: 游戏中的角色等级。
		paymentAmount	: 付费金额,单位为分。
	结果说明 : 布尔值，成功返回YES。

5. 玩家支付成功
+ (BOOL)onPayedSuccessfullyForAccountId:(NSString *)accountId roleId:(NSString *)roleId roleLevel:(NSUInteger)roleLevel paymentAmount:(double)paymentAmount;
	使用说明 : 在玩家支付成功后调用。
	参数说明 :
		accountId	: 游戏账号ID。
		roleId		: 游戏中的角色ID。
		roleLevel	: 游戏中的角色等级。
		paymentAmount	: 付费金额,单位为分。
	结果说明 : 布尔值，成功返回YES。

6. 玩家角色升级
+ (BOOL)onRoleUpWithAccountId:(NSString *)accountId roleId:(NSString *)roleId uptoRoleLevel:(NSUInteger)roleLevel;
	使用说明 : 在玩家游戏角色升级时调用。
	参数说明 :
		accountId	: 游戏账号ID。
		roleId 		: 游戏中的角色ID。
		roleLevel 	: 游戏中的角色等级。
	结果说明 : 布尔值，成功返回YES。

五 推广SDK接口说明

MiGameAdPlatform为推广SDK相关类，以下方法必须在MiGameStatistics的 + (BOOL)setup:(NSString *)gameId version:(NSString *)gameVersion channel:(NSString *)channel 之后调用，且在 - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions 之中调用。

1. 接入第三方广告商平台
+ (BOOL)initAdPlatformInMobiWithPropertyID:(NSString *)propertyID;
	参数说明 : 
		propertyID	: InMobile后台为app生成ID，不能为空。
	结果说明 : 布尔值，成功返回YES。

+ (BOOL)initAdPlatformChartBoostWithAppID:(NSString *)appID appSignature:(NSString *)appSignature;
	参数说明 :
		appID		: chartboost后台为app生成的ID和签名，不能为空。
		appSignature	: chartboost后台为app生成的签名，不能为空。
	结果说明 : 布尔值，成功返回YES。

+ (BOOL)initAdPlatformAdmobWithConversionID:(NSString *)conversionID label:(NSString *) label value:(NSString *) value isRepeatable:(BOOL)isRepeatable;
	参数说明 : 
		conversionID 	: Admob后台为app生成的ID，不能为空。
		label		: 对conversionID的描述，不能为空。
		value		: 每次转化都价值，对于游戏来说，会根据协商得到，不必关心，可以为空。
		isRepeatable 	: 建议设置为NO。
	结果说明 : 布尔值，成功返回YES。

+ (BOOL)initAdPlatformAdmobWithConversionID:(NSString *)conversionID label:(NSString *) label;
	参数说明 :
		conversionID 	: Admob后台为app生成的ID，不能为空。
		label		: 对conversionID的描述，不能为空。
	结果说明 : 布尔值，成功返回YES。

2. 接入第三方广告监控平台
+ (BOOL)initTalkingDataWithAppKey:(NSString *)appKey channelID:(NSString *)channelID;
	参数说明 :
		appKey		: TalkingData后台为app生成的ID，不能为空。
		channelID 	: 渠道跟踪ID，如果在AppStore上架，必须设置为"AppStore"，如果在国内第三方应用市场，或者越狱市场上架，请按照系统生成的ID为准；设置为空则使用默认值"AppStore"。
	结果说明 : 布尔值，成功返回YES。

+ (BOOL)initReYunWithAppKey:(NSString *)appKey channelID:(NSString *)channelID;
	参数说明 :
		appKey 		: ReYun后台为app生成的ID，不能为空。
		channelID 	: 渠道跟踪ID，设置为空则使用默认值"_default_"。
	结果说明 : 布尔值，成功返回YES。