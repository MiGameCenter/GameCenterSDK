//
//  ViewController.m
//  MiGameAdPlatformDemo
//
//  Created by 张朝杰 on 15/10/16.
//  Copyright (c) 2015年 zhangchaojie. All rights reserved.
//
#import "ViewController.h"
#import <MiGameSDK/MiGameSDK.h>

@implementation ViewController {
    UILabel *stateLabel;
    UILabel *resultLabel;
    // MiGameAccount
    UIButton *aLoginAccountButton;
    UIButton *aSwitchAccountButton;
    UIButton *aBindAccountButton;
    UIButton *aAccountStateButton;
    UIButton *aChangePasswordButton;
    UIButton *aLogoutButton;
    UIButton *aResetAllButton;
    // MiGameStatistics
    UIButton *sLoginButton;
    UIButton *sBeforePayButton;
    UIButton *sPayedSuccessfullyButton;
    UIButton *sRoleLevelUpButton;
    // View
    CGFloat width;
    CGFloat height;
    CGFloat pointY;
}

- (void)viewDidLoad {
    width = [UIScreen mainScreen].bounds.size.width;
    height = 35;
    pointY = 0;
    
    [super viewDidLoad];
    [self initLabelView];
    [self initAccountView];
    [self initStatisticsView];
    [self refreshLabel:@"Hello World!"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)initLabelView {
    
    stateLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, [self getNextPointY],width,height)];
    stateLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:stateLabel];
    
    resultLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, [self getNextPointY], width, height)];
    resultLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:resultLabel];
}

- (void)initAccountView {
    
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(30, pointY + height, width-60, 1)];
    line.backgroundColor = [UIColor grayColor];
    [self.view addSubview:line];
    
    aLoginAccountButton = [UIButton buttonWithType:UIButtonTypeSystem];
    aLoginAccountButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [aLoginAccountButton setTitle:@"Login Account" forState:UIControlStateNormal];
    [aLoginAccountButton addTarget:self action:@selector(onLoginAccountButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aLoginAccountButton];
    
    aSwitchAccountButton = [UIButton buttonWithType:UIButtonTypeSystem];
    aSwitchAccountButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [aSwitchAccountButton setTitle:@"Switch Account" forState:UIControlStateNormal];
    [aSwitchAccountButton addTarget:self action:@selector(onSwitchAccountButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aSwitchAccountButton];
    
    aBindAccountButton = [UIButton buttonWithType:UIButtonTypeSystem];
    aBindAccountButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [aBindAccountButton setTitle:@"Bind Account" forState:UIControlStateNormal];
    [aBindAccountButton addTarget:self action:@selector(onBindAccountButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aBindAccountButton];
    
    aAccountStateButton = [UIButton buttonWithType:UIButtonTypeSystem];
    aAccountStateButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [aAccountStateButton setTitle:@"Account State" forState:UIControlStateNormal];
    [aAccountStateButton addTarget:self action:@selector(onAccountStateButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aAccountStateButton];
    
    aChangePasswordButton = [UIButton buttonWithType:UIButtonTypeSystem];
    aChangePasswordButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [aChangePasswordButton setTitle:@"Change Password" forState:UIControlStateNormal];
    [aChangePasswordButton addTarget:self action:@selector(onChangePasswordButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aChangePasswordButton];
    
    aLogoutButton = [UIButton buttonWithType:UIButtonTypeSystem];
    aLogoutButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [aLogoutButton setTitle:@"Logout" forState:UIControlStateNormal];
    [aLogoutButton addTarget:self action:@selector(onLogoutButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:aLogoutButton];
}

- (void)initStatisticsView {
    
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(30, pointY + height, width-60, 1)];
    line.backgroundColor = [UIColor grayColor];
    [self.view addSubview:line];
    
    sLoginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    sLoginButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [sLoginButton setTitle:@"Login" forState:UIControlStateNormal];
    [sLoginButton addTarget:self action:@selector(onLoginButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sLoginButton];
    
    sBeforePayButton = [UIButton buttonWithType:UIButtonTypeSystem];
    sBeforePayButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [sBeforePayButton setTitle:@"Before Pay" forState:UIControlStateNormal];
    [sBeforePayButton addTarget:self action:@selector(onBeforePayButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sBeforePayButton];
    
    sPayedSuccessfullyButton = [UIButton buttonWithType:UIButtonTypeSystem];
    sPayedSuccessfullyButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [sPayedSuccessfullyButton setTitle:@"Payed Successfully" forState:UIControlStateNormal];
    [sPayedSuccessfullyButton addTarget:self action:@selector(onPayedSuccessfullyButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sPayedSuccessfullyButton];
    
    sRoleLevelUpButton = [UIButton buttonWithType:UIButtonTypeSystem];
    sRoleLevelUpButton.frame = CGRectMake(0, [self getNextPointY], width, height);
    [sRoleLevelUpButton setTitle:@"Role Level Up" forState:UIControlStateNormal];
    [sRoleLevelUpButton addTarget:self action:@selector(onRoleLevelUpButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sRoleLevelUpButton];
    
    sLoginButton.enabled = YES;
    sBeforePayButton.enabled = NO;
    sPayedSuccessfullyButton.enabled = NO;
    sRoleLevelUpButton.enabled = NO;
    
}

- (CGFloat)getNextPointY {
    return pointY += height;
}

- (void)refreshLabel:(NSString *)result {
    NSLog(@"%@", result);
    NSString *state;
    switch ([MiGameAccount miAccountState]) {
        case MiGameAccount_Login_Mi:
            state = @"Login_Mi";
            break;
        case MiGameAccount_Login_Guest:
            state = @"Login_Guest";
            break;
        default:
            state = @"Logout";
            break;
    }
    stateLabel.text = [NSString stringWithFormat:@"Account State: %@",state];
    resultLabel.text = result;
    // miBindAccount,miChangePassword,miLogout只能在相应状态下才能调用成功
    aBindAccountButton.enabled = ([MiGameAccount miAccountState] == MiGameAccount_Login_Guest);
    aChangePasswordButton.enabled = ([MiGameAccount miAccountState] == MiGameAccount_Login_Mi);
    aLogoutButton.enabled = ([MiGameAccount miAccountState] == MiGameAccount_Login_Mi);
}

#pragma mark - MiGameAccount

- (void)onLoginAccountButtonClick:(id)sender {
    [MiGameAccount miLoginAccount:^(NSString *gameUid) {
        NSString *result = [NSString stringWithFormat:@"Login Success, AccountId: %@", gameUid];
        [self refreshLabel:result];
    }];
}

- (void)onSwitchAccountButtonClick:(id)sender {
    [MiGameAccount miSwitchAccount:^(NSString *gameUid) {
        NSString *result = [NSString stringWithFormat:@"Switch Success, AccountId: %@",gameUid];
        [self refreshLabel:result];
    } orCancel:^{
        NSString *result = [NSString stringWithFormat:@"Switch Cancel"];
        [self refreshLabel:result];
    }];
}

- (void)onBindAccountButtonClick:(id)sender {
    BOOL bResult = [MiGameAccount miBindAccount:^(NSString *gameUid) {
        NSString *result = [NSString stringWithFormat:@"Bind Success, AccountId: %@",gameUid];
        [self refreshLabel:result];
    } orCancel:^{
        NSString *result = [NSString stringWithFormat:@"Bind Cancel"];
        [self refreshLabel:result];
    }];
    // 只有游客模式下才能绑定小米账号,游戏一般情况下不用对返回值进行处理,返回值为NO只为通知错误调用
    if (!bResult) {
        [self refreshLabel:@"Bind Failed"];
    }
}

- (void)onAccountStateButtonClick:(id)sender {
    NSString *accountState;
    switch ([MiGameAccount miAccountState]) {
        case MiGameAccount_Login_Mi:
            accountState = @"Login_Mi";
            break;
        case MiGameAccount_Login_Guest:
            accountState = @"Login_Guest";
            break;
        default:
            accountState = @"Logout";
            break;
    }
    [self refreshLabel:accountState];
}

- (void)onChangePasswordButtonClick:(id)sender {
    // 只有小米账号模式下才能修改小米账号密码,游戏一般情况下不用对返回值进行处理,返回值为NO只为通知错误调用
    if ([MiGameAccount miChangePassword]) {
        [self refreshLabel:@"Change Password Success"];
    } else {
        [self refreshLabel:@"Change Password Failed"];
    }
    
}

- (void)onLogoutButtonClick:(id)sender {
    // 只有小米账号模式下才能登出小米账号,游戏一般情况下不用对返回值进行处理,返回值为NO只为通知错误调用
    if ([MiGameAccount miLogout]) {
        [self refreshLabel:@"Logout Success"];
    } else {
        [self refreshLabel:@"Logout Failed"];
    }
}

#pragma mark - MiGameStatistics

- (void)onLoginButtonClick:(id)sender {
    [MiGameStatistics onLoginWithRoleId:@"tester" roleLevel:@"1"];
    [self refreshLabel:@"Statistice: Login"];
    sLoginButton.enabled = NO;
    sBeforePayButton.enabled = YES;
    sPayedSuccessfullyButton.enabled = NO;
    sRoleLevelUpButton.enabled = YES;
}

- (void)onBeforePayButtonClick:(id)sender {
    [MiGameStatistics onBeforePayForRoleId:@"tester" roleLevel:@"1" paymentAmount:@"100"];
    [self refreshLabel:@"Statistice: Before Pay"];
    sLoginButton.enabled = NO;
    sBeforePayButton.enabled = YES;
    sPayedSuccessfullyButton.enabled = YES;
    sRoleLevelUpButton.enabled = YES;
    
}

- (void)onPayedSuccessfullyButtonClick:(id)sender {
    [MiGameStatistics onPayedSuccessfullyForRoleId:@"tester" roleLevel:@"1" paymentAmount:@"100"];
    [self refreshLabel:@"Statistice: Payed Successfully"];
    sLoginButton.enabled = NO;
    sBeforePayButton.enabled = YES;
    sPayedSuccessfullyButton.enabled = NO;
    sRoleLevelUpButton.enabled = YES;
    
}

- (void)onRoleLevelUpButtonClick:(id)sender {
    [MiGameStatistics onRoleLevelUpWithRoleId:@"tester" uptoRoleLevel:@"2"];
    [self refreshLabel:@"Statistice: Role Level Up"];
}

@end
