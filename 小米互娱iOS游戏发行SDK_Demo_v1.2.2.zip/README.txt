小米互娱iOS游戏发行SDK(1.2.2)
====================

小米互娱游戏发行SDK规范-iOS版
本文档帮助游戏开发商(简称CP)将游戏接入小米互娱iOS游戏发行SDK(简称SDK)。

历史版本信息
//TODO

一 目录结构

SDK目录							//账号SDK、统计SDK
	|--MiGameSDK.framework
	|--MiGameBundle.Bundle
MiGameSDKDemo						//SDK Demo
README.txt						//说明文档

二 接入说明

1. 运行环境
	iOS 5.1.1 以上
	Xcode 6.0 以上

2. 接入方法
	(1)将以上组合中的framework包添加到Build Phases - Link Binary With Libraries，bundle包添加到Copy Bundle Resources。
	(2)额外添加libz.dylib(或libz.tbd)到Build Phases - Link Binary With Libraries(如果已添加请忽略)。
	(3)添加"-ObjC"到Build Settings - Other Linker Flags。

三 初始化SDK接口说明

MiGameSDK为初始化SDK相关类
+ (void)setupWithAppId:(NSString *)appId;
	使用说明 : - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;之中调用。
	参数说明 : appId由运营的同学提供，类型为数字字符串。

四 账号SDK接口说明

MiGameAccount为账号SDK相关类

1. 自动登录
+ (void)miLoginAccount:(void(^)(NSString *gameUid))success;
	使用说明 : 没有使用过小米账号登录将以游客模式登录，已使用小米账号登录将以最后登录的小米账号登录。
	结果说明 :
		登录成功 : 调用(void(^)(NSString *gameUid))success，返回gameUid。

2. 切换小米账号
+ (void)miSwitchAccount:(void(^)(NSString *gameUid))success orCancel:(void(^)())cancel;
	使用说明 : 弹出注册/登录小米账号界面，注册或登录成功将返回小米账号新建的或已绑定的gameUid，游客模式下的gameUid被覆盖。
	结果说明 :
		切换成功 : 调用(void(^)(NSString *gameUid))success，返回gameUid。
		切换取消 : 调用(void(^)())cancel。

3. 绑定小米账号
+ (BOOL)miBindAccount:(void(^)(NSString *gameUid))success orCancel:(void(^)())cancel;
	使用说明 : 弹出注册/绑定小米账号界面，注册或绑定成功将返回小米账号绑定的gameUid，此gameUid与游客模式下的gameUid一致，游客模式下的gmaeUid不会被覆盖。
	结果说明 : 游客模式下返回YES,未登录或小米账号模式下返回NO。
		绑定成功 : 调用(void(^)(NSString *gameUid))success，返回gameUid。
		绑定取消 : 调用(void(^)())cancel。

4. 获取当前账号类型
+ (MiGameAccountState)miAccountState;
	使用说明 : 获取当前账号的类型，包括未登录、游客模式登录、小米账号登录。
	结果说明 : MiGameAccountState是枚举类型，有MiGameAccount_Logout、MiGameAccount_Login_Guest、MiGameAccount_Login_Mi三个值，对应以上三种状态。

5. 修改小米账号密码
+ (BOOL)miChangePassword;
	使用说明 : 跳转到浏览器进行修改小米账号密码操作。
	结果说明 : 小米账号模式下返回YES(游客模式下不能修改密码返回NO)。

6. 登出小米账号
- (BOOL)miLogout;
	使用说明 : 清除本地小米账号信息，保留本地游客账号信息。
	结果说明 : 小米账号模式下登出成功返回YES(游客模式下不能登出返回NO)。

五 统计SDK接口说明

MiGameStatistics为统计SDK相关类

1. 玩家登陆游戏
+ (BOOL)onLoginWithAccountId:(NSString *)accountId roleId:(NSString *)roleId roleLevel:(NSString *)roleLevel;
	使用说明 : 在玩家登陆游戏后调用。
	参数说明 :
		accountId 	: 游戏账号ID。
		roleId 		: 游戏中的角色ID。
		roleLevel 	: 游戏中的角色等级。
	结果说明 : 布尔值，成功返回YES。

2. 玩家支付前
+ (BOOL)onBeforePayForRoleId:(NSString *)roleId roleLevel:(NSString *)roleLevel paymentAmount:(NSString *)paymentAmount;
	使用说明 : 在玩家支付前调用。
	参数说明 :
		roleId		: 游戏中的角色ID。
		roleLevel	: 游戏中的角色等级。
		paymentAmount	: 付费金额,单位为分。
	结果说明 : 布尔值，成功返回YES。

3. 玩家支付成功
+ (BOOL)onPayedSuccessfullyForAccountId:(NSString *)accountId roleId:(NSString *)roleId roleLevel:(NSString *)roleLevel paymentAmount:(NSString *)paymentAmount;
	使用说明 : 在玩家支付成功后调用。
	参数说明 :
		roleId		: 游戏中的角色ID。
		roleLevel	: 游戏中的角色等级。
		paymentAmount	: 付费金额,单位为分。
	结果说明 : 布尔值，成功返回YES。

4. 玩家角色升级
+ (BOOL)onRoleUpWithRoleId:(NSString *)roleId uptoRoleLevel:(NSString *)roleLevel;
	使用说明 : 在玩家游戏角色升级时调用。
	参数说明 :
		roleId 		: 游戏中的角色ID。
		roleLevel 	: 游戏中的角色等级。
	结果说明 : 布尔值，成功返回YES。