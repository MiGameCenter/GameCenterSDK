//
//  MiGameAccount.h
//  MiGameSDK
//
//  Created by 张朝杰 on 15/10/15.
//  Copyright (c) 2015年 XiaoMi. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 登录状态
 */
typedef enum {
    MiGameAccount_Logout = 0,
    MiGameAccount_Login_Guest = 1,
    MiGameAccount_Login_Mi = 2,
} MiGameAccountState;

@interface MiGameAccount : NSObject

/**
 * 一键登录,自动选择游客或小米账号登录
 */
+ (void)miLoginAccount:(void(^)(NSString *gameUid))success;

/**
 * 切换帐号,弹出界面
 */
+ (void)miSwitchAccount:(void(^)(NSString *gameUid))success orCancel:(void(^)())cancel;

/**
 * 绑定帐号,弹出界面(游客身份生效)
 */
+ (BOOL)miBindAccount:(void(^)(NSString *gameUid))success orCancel:(void(^)())cancel;

/**
 * 获取当前账号类型
 */
+ (MiGameAccountState)miAccountState;

/**
 * 修改小米帐号密码(当前账号为小米账号)
 */
+ (BOOL)miChangePassword;

/**
 * 登出操作(游客身份登出无效)
 */
+ (BOOL)miLogout;

@end