//
//  MiGameSDK.h
//  MiGameSDK
//
//  Created by 张朝杰 on 10/15/15.
//  Copyright (c) 2015 XiaoMi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MiGameSDK/MiGameAccount.h>
#import <MiGameSDK/MiGameStatistics.h>

@interface MiGameSDK : NSObject

+ (void)setupWithAppId:(NSString *)appId;

@end