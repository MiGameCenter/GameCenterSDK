//
//  MiGameStatistics.h
//  MiGameSDK
//
//  Created by 张朝杰 on 15/10/15.
//  Copyright (c) 2015年 XiaoMi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MiGameStatistics : NSObject

/**
 *  Do check point when role |roleId| of level |roleLevel| logged in
 *
 *  @param roleId       the id or role in the game
 *  @param roleLevel    the level that role
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onLoginWithRoleId:(NSString *)roleId
                roleLevel:(NSString *)roleLevel;

/**
 *  Do check point when role |roleId| of level |roleLevel| start to pay money of |paymentAmount|
 *
 *  @param roleId       the id or role in the game
 *  @param roleLevel    the level that role comes up to
 *  @param paymentAmount payment amount
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onBeforePayForRoleId:(NSString *)roleId
                   roleLevel:(NSString *)roleLevel
               paymentAmount:(NSString *)paymentAmount;

/**
 *  Do check point when role |roleId| of level |roleLevel| payed the money of |paymentAmount|
 *
 *  @param roleId           the id or role in the game
 *  @param roleLevel        the level that role comes up to
 *  @param paymentAmount    payment amount
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onPayedSuccessfullyForRoleId:(NSString *)roleId
                           roleLevel:(NSString *)roleLevel
                       paymentAmount:(NSString *)paymentAmount;

/**
 *  Do check point when role |roleId| comes to a new level |roleLevel|
 *
 *  @param roleId       the id or role in the game
 *  @param roleLevel    the level that role comes up to
 *
 *  @return YES if the check point is made.
 */
+ (BOOL)onRoleLevelUpWithRoleId:(NSString *)roleId
                  uptoRoleLevel:(NSString *)roleLevel;

@end