package com.sdk.migame.payment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.huyu.gamecenter.sdk.HyCommplatform;
import com.huyu.gamecenter.sdk.HyErrorCode;
import com.huyu.gamecenter.sdk.OnHyLoginProcessListener;
import com.sdk.migame.payment.hy.R;

public class OnlineFirstActivity extends Activity implements OnHyLoginProcessListener
{

	private String from;

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		this.requestWindowFeature( Window.FEATURE_NO_TITLE );

		LinearLayout layout = new LinearLayout( this );
		layout.setBackgroundResource( R.drawable.online1 );
		layout.setGravity( Gravity.CENTER );
		setContentView( layout, new LinearLayout.LayoutParams( -1, -1 ) );

		from = getIntent().getStringExtra( "from" );

		layout.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					HyCommplatform.getInstance().hyLogin( OnlineFirstActivity.this, OnlineFirstActivity.this );
				}
			} );
	}

	@Override
	public void finishLoginProcess( int arg0 )
	{
		switch( arg0 )
		{
			case HyErrorCode.MI_XIAOMI_GAMECENTER_ERROR_CANCEL:
				handler.sendEmptyMessage( 10000 );
			break;
			case HyErrorCode.MI_XIAOMI_GAMECENTER_ERROR_LOGIN_FAIL:
				handler.sendEmptyMessage( 20000 );
			break;
			case HyErrorCode.MI_XIAOMI_GAMECENTER_SUCCESS:
				handler.sendEmptyMessage( 30000 );
			break;
			case HyErrorCode.MI_XIAOMI_GAMECENTER_ERROR_ACCOUNT_USE_GAME_ACCOUNT:
				handler.sendEmptyMessage( 40000 );
			break;
			default:
			break;
		}
	}

	private Handler handler = new Handler()
		{
			@Override
			public void handleMessage( android.os.Message msg )
			{
				switch( msg.what )
				{
					case 10000:
						Toast.makeText( OnlineFirstActivity.this, "取消登录", Toast.LENGTH_LONG ).show();
					break;
					case 20000:
						Toast.makeText( OnlineFirstActivity.this, "登录失败", Toast.LENGTH_LONG ).show();
					break;
					case 30000:
						Toast.makeText( OnlineFirstActivity.this, "登录成功", Toast.LENGTH_LONG ).show();
						if ( from.equals( "alipay" ) )
						{
							Intent intent = new Intent( OnlineFirstActivity.this, OnlineSecActivity.class );
							intent.putExtra( "payType", getIntent().getBooleanExtra( "payType", true ) );
							startActivity( intent );
						}
					break;
					case 40000:
						Toast.makeText( OnlineFirstActivity.this, "使用游戏账户登录", Toast.LENGTH_LONG ).show();
					default:
					break;
				}
			};
		};

}
