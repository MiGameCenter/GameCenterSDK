package com.sdk.migame.payment;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.huyu.gamecenter.sdk.HyCommplatform;
import com.huyu.gamecenter.sdk.HyErrorCode;
import com.huyu.gamecenter.sdk.OnHyPayProcessListener;
import com.huyu.gamecenter.sdk.entry.HyBuyInfo;

public class OnlineSecActivity extends Activity implements OnHyPayProcessListener
{
	private EditText mEditText;
	
	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );

		this.requestWindowFeature( Window.FEATURE_NO_TITLE );

		LinearLayout layout = new LinearLayout( this );
		layout.setBackgroundColor( Color.WHITE );
		layout.setOrientation( LinearLayout.VERTICAL );
		setContentView( layout, new LinearLayout.LayoutParams( -1, -1 ) );

		TextView mTextView = new TextView( this );
		mTextView.setText( "请选择充值金额" );
		mTextView.setTextColor( Color.BLACK );
		mTextView.setGravity( Gravity.CENTER_HORIZONTAL );
		mTextView.setTextSize( 20 );
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams( -1, -2 );
		lp.setMargins( 0, 20, 0, 8 );
		layout.addView( mTextView, lp );

		LinearLayout itemLayout1 = new LinearLayout( this );
		lp = new LinearLayout.LayoutParams(-1, -2 );
		layout.addView( itemLayout1, lp );
		
		Button button1 = new Button( this );
		button1.setText( "1元(1游戏币)" );
		lp = new LinearLayout.LayoutParams( 0, -2, 1 );
		itemLayout1.addView( button1, lp );
		button1.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					mEditText.setText( "1" );
				}
			} );
		
		button1 = new Button( this );
		button1.setText( "5元(5游戏币)" );
		lp = new LinearLayout.LayoutParams( 0, -2, 1 );
		itemLayout1.addView( button1, lp );
		button1.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					mEditText.setText( "5" );
				}
			} );
		
		LinearLayout itemLayout2 = new LinearLayout( this );
		lp = new LinearLayout.LayoutParams(-1, -2 );
		layout.addView( itemLayout2, lp );
		
		button1 = new Button( this );
		button1.setText( "10元(10游戏币)" );
		lp = new LinearLayout.LayoutParams( 0, -2, 1 );
		itemLayout2.addView( button1, lp );
		button1.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					mEditText.setText( "10" );
				}
			} );
		
		button1 = new Button( this );
		button1.setText( "50元(50游戏币)" );
		lp = new LinearLayout.LayoutParams( 0, -2, 1 );
		itemLayout2.addView( button1, lp );
		button1.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					mEditText.setText( "50" );
				}
			} );
		
		LinearLayout itemLayout3 = new LinearLayout( this );
		lp = new LinearLayout.LayoutParams(-1, -2 );
		layout.addView( itemLayout3, lp );
		
		button1 = new Button( this );
		button1.setText( "100元(100游戏币)" );
		lp = new LinearLayout.LayoutParams( 0, -2, 1 );
		itemLayout3.addView( button1, lp );
		button1.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					mEditText.setText( "100" );
				}
			} );
		
		button1 = new Button( this );
		button1.setText( "500元(500游戏币)" );
		lp = new LinearLayout.LayoutParams( 0, -2, 1 );
		itemLayout3.addView( button1, lp );
		button1.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					mEditText.setText( "500" );
				}
			} );
		
		mEditText = new EditText( this );
		mEditText.setHint( "请输入充值金额" );
		setDigits( mEditText, false );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		lp.setMargins( 40, 10, 40, 0 );
		layout.addView( mEditText, lp );
		
		TextView tipTextView = new TextView( this );
		tipTextView.setTextColor( Color.BLACK );
		tipTextView.setTextSize( 18 );
		tipTextView.setText( "1游戏币=1人民币" );
		lp = new LinearLayout.LayoutParams( -2, -2 );
		lp.leftMargin = 30;
		lp.topMargin = 50;
		layout.addView( tipTextView, lp );
		
		Button payBtn = new Button( this );
		payBtn.setText( "确定" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		lp.setMargins( 100, 20, 100, 0 );
		layout.addView( payBtn, lp );
		payBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					if(TextUtils.isEmpty( mEditText.getText().toString() ))
						return;
					
					if(mEditText.getText().toString().startsWith( "0" ))
						return;
					
					int money = Integer.parseInt( mEditText.getText().toString() );
					
					HyBuyInfo buyInfo = new HyBuyInfo();
					buyInfo.setAmount( money );
					buyInfo.setCpUserInfo( "xxxxxx" );
					buyInfo.setCpOrderId( HyCommplatform.getInstance().generateCpOrderId() );
					
					HyCommplatform.getInstance().hyUniPay( OnlineSecActivity.this, buyInfo, OnlineSecActivity.this );
				}
			} );
		
		TextView tipTextView1 = new TextView( this );
		tipTextView1.setTextColor( Color.BLACK );
		tipTextView1.setTextSize( 18 );
		tipTextView1.setText( "在正式环境中一定要注明游戏币和人民币的关系" );
		lp = new LinearLayout.LayoutParams( -2, -2 );
		lp.leftMargin = 30;
		lp.rightMargin = 30;
		layout.addView( tipTextView1, lp );
	}

	private Handler handler = new Handler()
		{
			@Override
			public void handleMessage( android.os.Message msg )
			{
				switch( msg.what )
				{
					case 10000:
						Toast.makeText( OnlineSecActivity.this, "购买成功", Toast.LENGTH_SHORT ).show();
					break;
					case 30000:
						Toast.makeText( OnlineSecActivity.this, "购买失败", Toast.LENGTH_LONG ).show();
					break;
					default:
					break;
				}
			};
		};

	@Override
	public void finishPayProcess( int arg0 )
	{
		if ( arg0 == HyErrorCode.MI_XIAOMI_GAMECENTER_SUCCESS )// 成功
		{
			handler.sendEmptyMessage( 10000 );
		}
		else if ( arg0 == HyErrorCode.MI_XIAOMI_GAMECENTER_ERROR_PAY_FAILURE )// 失败
		{
			handler.sendEmptyMessage( 30000 );
		}
	}
	
	private void setDigits(EditText et, boolean bDecimal)
	{
		InputFilter[] filters = {new InputFilter.LengthFilter(5)};
		et.setFilters(filters);
		et.setKeyListener(new DigitsKeyListener(false, bDecimal));
	}
}
