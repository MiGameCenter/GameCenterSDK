package com.sdk.migame.payment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.huyu.gamecenter.sdk.HyCommplatform;
import com.huyu.gamecenter.sdk.HyErrorCode;
import com.huyu.gamecenter.sdk.OnHyLoginProcessListener;
import com.huyu.gamecenter.sdk.entry.HyAppInfo;

public class MainActivity extends Activity implements OnHyLoginProcessListener
{
	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		
		HyAppInfo hyAppInfo = new HyAppInfo();
		hyAppInfo.setAppId( "2882303761517239138" );
		hyAppInfo.setAppKey( "5691723970138" );
		HyCommplatform.Init( this, hyAppInfo );

		RelativeLayout.LayoutParams rlp;
		LinearLayout.LayoutParams lp;

		RelativeLayout rLayout = new RelativeLayout( this );
		rLayout.setBackgroundColor( Color.WHITE );
		this.setContentView( rLayout, new LinearLayout.LayoutParams( -1, -1 ) );

		LinearLayout btnLayout = new LinearLayout( this );
		btnLayout.setOrientation( LinearLayout.VERTICAL );
		rlp = new RelativeLayout.LayoutParams( -1, -2 );
		rLayout.addView( btnLayout, rlp );

		TextView mTextView = new TextView( this );
		mTextView.setText( "官方SDK DEMO游戏流程演示" );
		mTextView.setTextColor( Color.BLACK );
		mTextView.setGravity( Gravity.CENTER_HORIZONTAL );
		mTextView.setTextSize( 20 );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		lp.setMargins( 0, 15, 0, 15 );
		btnLayout.addView( mTextView, lp );

		View view = new View( this );
		view.setBackgroundColor( Color.BLACK );
		lp = new LinearLayout.LayoutParams( -1, 2 );
		lp.setMargins( 15, 0, 15, 0 );
		btnLayout.addView( view, lp );

		Button loginBtn = new Button( this );
		loginBtn.setText( "登录游戏账户" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		btnLayout.addView( loginBtn, lp );
		loginBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					HyCommplatform.getInstance().hyLogin( MainActivity.this, MainActivity.this );
				}
			} );

		Button aliPayBtn = new Button( this );
		aliPayBtn.setText( "支付宝充值" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		btnLayout.addView( aliPayBtn, lp );
		aliPayBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					Intent i2 = new Intent( MainActivity.this, OnlineSecActivity.class );
					startActivity( i2 );
				}
			} );
		
		Button roleLoginBtn = new Button( this );
		roleLoginBtn.setText( "roleLogin" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		btnLayout.addView( roleLoginBtn, lp );
		roleLoginBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					boolean success = HyCommplatform.roleLogin( "100001", "1" );
					Toast.makeText( MainActivity.this, String.valueOf( success ), Toast.LENGTH_SHORT ).show();
				}
			} );
		
		Button leveUpgradeBtn = new Button( this );
		leveUpgradeBtn.setText( "roleLevelUpgrade" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		btnLayout.addView( leveUpgradeBtn, lp );
		leveUpgradeBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					boolean success = HyCommplatform.roleLevelUpgrade( "123456789", "2" );
					Toast.makeText( MainActivity.this, String.valueOf( success ), Toast.LENGTH_SHORT ).show();
				}
			} );
		
		
		Button foregroundTImeBtn = new Button( this );
		foregroundTImeBtn.setText( "setForegroundTime" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		btnLayout.addView( foregroundTImeBtn, lp );
		foregroundTImeBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					boolean success = HyCommplatform.setForegroundTime();
					Toast.makeText( MainActivity.this, String.valueOf( success ), Toast.LENGTH_SHORT ).show();
				}
			} );
		
		Button uploadDurationBtn = new Button( this );
		uploadDurationBtn.setText( "uploadDuration" );
		lp = new LinearLayout.LayoutParams( -1, -2 );
		btnLayout.addView( uploadDurationBtn, lp );
		uploadDurationBtn.setOnClickListener( new OnClickListener()
			{
				@Override
				public void onClick( View v )
				{
					boolean success = HyCommplatform.uploadDuration();
					Toast.makeText( MainActivity.this, String.valueOf( success ), Toast.LENGTH_SHORT ).show();
				}
			} );
	}

	private Handler handler = new Handler()
		{
			@Override
			public void handleMessage( Message msg )
			{
				switch( msg.what )
				{
					case 10000:
						Toast.makeText( MainActivity.this, "登录成功", Toast.LENGTH_SHORT ).show();
					break;
					case 20000:
						Toast.makeText( MainActivity.this, "登录失败", Toast.LENGTH_SHORT ).show();
					break;
					default:
					break;
				}
			};
		};

	@Override
	public void finishLoginProcess( int code )
	{
		if ( HyErrorCode.MI_XIAOMI_GAMECENTER_SUCCESS == code )
		{
			handler.sendEmptyMessage( 10000 );
		}
		else
		{
			handler.sendEmptyMessage( 20000 );
		}
	};
}
