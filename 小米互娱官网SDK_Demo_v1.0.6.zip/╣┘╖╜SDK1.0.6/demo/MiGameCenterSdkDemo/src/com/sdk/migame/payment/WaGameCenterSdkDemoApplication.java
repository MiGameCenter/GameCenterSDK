package com.sdk.migame.payment;

import android.app.Application;
import android.os.StrictMode;

public class WaGameCenterSdkDemoApplication extends Application
{
	@Override
	public void onCreate()
	{
//		setStrictMode();
		super.onCreate();
	}
	
	private void setStrictMode()
	{
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
        .detectDiskReads()
        .detectDiskWrites()
        .detectNetwork()  
        .penaltyLog()
        .detectAll()
        .build());
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
		.detectLeakedSqlLiteObjects()
		.penaltyLog() 
		.detectAll()
		.penaltyDeath()
		.build());
		
		if (android.os.Build.VERSION.SDK_INT > 9) 
		{
		   StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		   StrictMode.setThreadPolicy(policy);
		}
	}
}
