/** Automatically generated file. DO NOT MODIFY */
package com.sdk.migame.payment.hy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}