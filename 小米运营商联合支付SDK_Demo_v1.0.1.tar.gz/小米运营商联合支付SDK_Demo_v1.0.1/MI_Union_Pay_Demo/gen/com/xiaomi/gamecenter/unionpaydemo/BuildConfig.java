/** Automatically generated file. DO NOT MODIFY */
package com.xiaomi.gamecenter.unionpaydemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}