package com.xiaomi.gamecenter.unionpaydemo;

import com.xiaomi.gamecenter.sdk.entry.MiAppInfo;
import com.xiaomi.gamecenter.unionpay.ChinaCommplatform;

import android.app.Application;

public class MiUnionPayApplication extends Application{
	private MiAppInfo appInfo=new MiAppInfo();
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		System.loadLibrary("megjb");
		appInfo.setAppId("2882303761517402635");
//		appInfo.setAppId("12698");
		appInfo.setAppKey("5151740219635");
		ChinaCommplatform.init(this,appInfo);
	}
}
