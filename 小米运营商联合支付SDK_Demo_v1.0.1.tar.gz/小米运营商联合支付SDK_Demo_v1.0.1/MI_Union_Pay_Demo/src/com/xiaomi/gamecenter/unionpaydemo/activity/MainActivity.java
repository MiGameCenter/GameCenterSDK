package com.xiaomi.gamecenter.unionpaydemo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import cn.cmgame.billing.api.GameInterface.IPayCallback;

import com.unicom.dcLoader.Utils;
import com.unicom.dcLoader.Utils.UnipayPayResultListener;
import com.xiaomi.gamecenter.unionpay.ChinaCommplatform;
import com.xiaomi.gamecenter.unionpay.IUnionPayCallback;
import com.xiaomi.gamecenter.unionpaydemo.R;

public class MainActivity extends Activity implements OnClickListener {

private Button btnChinaMobile,btnChinaUnicom,btnUnionPay;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
       ChinaCommplatform.getInstance().initPay(this);
		btnChinaMobile=(Button)findViewById(R.id.btn_chinaMobile);
		btnChinaUnicom=(Button)findViewById(R.id.btn_chinaUnicom);
		btnUnionPay = (Button)findViewById(R.id.btn_unionPay);
		btnChinaMobile.setOnClickListener(this);
		btnChinaUnicom.setOnClickListener(this);
		btnUnionPay.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_unionPay:
			try {
				ChinaCommplatform.getInstance().unionPay(MainActivity.this, "a_a12345", new IUnionPayCallback() {
					@Override
					public void unionPayResult(int resultCode) {
						// TODO Auto-generated method stub
						switch (resultCode) {
						case IUnionPayCallback.UNION_PAY_SUCCESS:
							Toast.makeText(MainActivity.this, "支付成功", Toast.LENGTH_LONG).show();
							break;
						case IUnionPayCallback.UNION_PAY__FAIL:
							Toast.makeText(MainActivity.this, "支付失败", Toast.LENGTH_LONG).show();
							break;
						default:
							break;
						}
					}
				});
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case R.id.btn_chinaMobile:
			ChinaCommplatform.getInstance().chinaMobilePay(MainActivity.this,true, "001", new IPayCallback() {
				@Override
				public void onResult(int resultCode, String billingIndex, Object obj) {
					// TODO Auto-generated method stub
					   String result = "";
				        switch (resultCode) {
				          case 1:
						    if((10+"").equals(obj.toString())){
					           result = "短信计费超时";
					        }else{
							   result = "购买道具：[" + billingIndex + "] 成功！";
						    }
				            break;
				          case 2: 
				            result = "购买道具：[" + billingIndex + "] 失败！";
				            break;
				          default:
				            result = "购买道具：[" + billingIndex + "] 取消！";
				            break;
				        }
				        Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
				}
			} );
			break;
		case R.id.btn_chinaUnicom:
			ChinaCommplatform.getInstance().chinaUnicomPay(MainActivity.this, "001", new UnipayPayResultListener() {
				@Override
				public void PayResult(String arg0, int arg1, int arg2, String arg3) {
					// TODO Auto-generated method stub
						switch (arg1) {
						case 1://success
							//此处放置支付请求已提交的相关处理代码
							Toast.makeText(MainActivity.this,  "支付成功", Toast.LENGTH_SHORT).show();
							break;

						case 2://fail
							//此处放置支付请求失败的相关处理代码
							Toast.makeText(MainActivity.this,  "支付失败", Toast.LENGTH_SHORT).show();
							break;
							
						case 3://cancel
							//此处放置支付请求被取消的相关处理代码
							Toast.makeText(MainActivity.this,  "支付取消", Toast.LENGTH_SHORT).show();
							break;
							
						default:
							Toast.makeText(MainActivity.this,  "支付结果未知", Toast.LENGTH_SHORT).show();
							break;
						}
				}
			});
			break;
			
		default:
			break;
		}
		
	}
	
	
	
	@Override
	protected void onResume() {
		super.onResume();
		Utils.getInstances().onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		Utils.getInstances().onPause(this);
	}


}
