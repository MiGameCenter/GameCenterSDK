package com.xiaomi.gamecenter.unionpay;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;
import com.umpay.huafubao.UpPay;
import com.umpay.huafubao.UpPayListener;
import com.unicom.dcLoader.Utils;
import com.unicom.dcLoader.Utils.UnipayPayResultListener;
import com.wali.gamecenter.report.ReportManager;
import com.wali.gamecenter.report.model.XmsdkReport;
import com.xiaomi.gamecenter.sdk.MiCommplatform;
import com.xiaomi.gamecenter.sdk.MiErrorCode;
import com.xiaomi.gamecenter.sdk.entry.MiAppInfo;
import com.xiaomi.gamecenter.sdk.entry.MiBuyInfo;
import com.xiaomi.gamecenter.unionpay.config.URLConfig;
import com.xiaomi.gamecenter.unionpay.http.RestClient;
import com.xiaomi.gamecenter.unionpay.log.Logger;
import com.xiaomi.gamecenter.unionpay.model.BillingCodeModel;
import com.xiaomi.gamecenter.unionpay.model.BillingModel;
import com.xiaomi.gamecenter.unionpay.report.ReportCode;
import com.xiaomi.gamecenter.unionpay.util.AESUtils;
import com.xiaomi.gamecenter.unionpay.util.ConnectUtil;
import com.xiaomi.gamecenter.unionpay.util.FileUtil;
import com.xiaomi.gamecenter.unionpay.util.SignUtils;
import com.xiaomi.gamecenter.unionpay.util.TelUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import cn.cmgame.billing.api.GameInterface;
import cn.cmgame.billing.api.GameInterface.IPayCallback;
import cz.msebera.android.httpclient.Header;

public class ChinaCommplatform {
	private volatile static ChinaCommplatform mInstance;  
	private static final String FILE_BILLINGINDEX_NAME="mi_billing.dat";
    private static final String AES_KEY="clientkey";
	private  Context mContext;
	private MiAppInfo mAppInfo;
    private CountDownTimer timer;
	public ChinaCommplatform(Context context,MiAppInfo appInfo){
		this.mContext=context;
		this.mAppInfo=appInfo;
		Utils.getInstances().initSDK(mContext,new UnipayPayResultListener() {
			@Override
			public void PayResult(String arg0, int arg1, int arg2, String arg3) {
                Log.e("initSDK",arg0+arg3);
			}
		});
		MiCommplatform.Init( context, appInfo );
//		ActiveAndroid.initialize(context);
//		ReportManager.init(context, appInfo);
//        DBManager.init(context);
        ReportManager.Init(context,true);
        if (Logger.printLog){
            ReportManager.getInstance().setDebug(true);
        }
		//统计数据存储
		requestCode(context);//请求计费文件

	}
	public static void init(Context context,MiAppInfo appInfo ){
		if(null == mInstance){
			mInstance=new ChinaCommplatform(context,appInfo);
		}
	}
	public static void initPay(Activity activity){
		GameInterface.initializeApp(activity);
	}
	public static ChinaCommplatform getInstance() {  
		if (mInstance == null) {  
			throw new IllegalStateException( "使用SDK前请先调用ChinaCommplatform.init()" );
    	}  
	    return mInstance;  
	}  
	public void chinaMobilePay(Activity activity,boolean isRepeated,String billingIndex,IPayCallback callback){
		  GameInterface.doBilling(activity, true, isRepeated, billingIndex, null, callback);
	}
	public void chinaUnicomPay(Context context,String billingIndex,UnipayPayResultListener listener){
		Utils.getInstances().pay(context, billingIndex, listener);
	}
	/**
	 * 联合支付-小米支付
	 * **/
	private void unionMiPay(final Activity activity,final BillingCodeModel billingCodeModel,final IUnionPayCallback uCallback ){
        report(ReportCode.CODE_MI_CALLED);
		new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				int code=MiBuy.getInstance().buyForMiUniPay(activity, createMiBuyInfo(billingCodeModel.getMiCode()));
				if(code==MiErrorCode.MI_XIAOMI_PAYMENT_SUCCESS){
					activity.runOnUiThread(new Runnable() {
						@Override
						public void run() {
							uCallback.unionPayResult(IUnionPayCallback.UNION_PAY_SUCCESS);
                            report(ReportCode.CODE_MI_SUCCESS);

						}
					});
				}else{
					activity.runOnUiThread(new Runnable() {
						@Override
						public void run() {
							uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                            report(ReportCode.CODE_MI_FAIL);
						}
					});
				}
			}
		}).start();
	}
	/**
	 * 联合支付-中移动支付
	 * **/
	private void unionChinaMobilePay(final Activity activity,BillingCodeModel billingCodeModel,final IUnionPayCallback uCallback){
        report(ReportCode.CODE_CHINAMOBILE_CALLED);
    	String code = billingCodeModel.getChinaMobileCode();
    	if(TextUtils.isEmpty(code)){
    		System.out.println("请检查移动计费代码！");
    	}
		ChinaCommplatform.getInstance().chinaMobilePay(activity, true, code, new IPayCallback() {
			@Override
			public void onResult(int resultCode, String billingIndex, Object obj) {
				// TODO Auto-generated method stub
			        switch (resultCode) {
			          case 1:
					    if((10+"").equals(obj.toString())){
					    	uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                            report(ReportCode.CODE_CHINAMOBILE_FAIL);
				        }else{
				        	uCallback.unionPayResult(IUnionPayCallback.UNION_PAY_SUCCESS);
                            report(ReportCode.CODE_CHINAMOBILE_SUCCESS);

                        }
			            break;
			          case 2: 
			        	  uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                          report(ReportCode.CODE_CHINAMOBILE_FAIL);
			            break;
			          default:
			        	  uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                          report(ReportCode.CODE_CHINAMOBILE_FAIL);
			            break;
			        }
			}
		});
	}
	/**
	 * 联合支付-中联通支付
	 * **/
	private void unionChinaUnicomPay(final Activity activity,BillingCodeModel billingCodeModel,final IUnionPayCallback uCallback){
        report(ReportCode.CODE_CHINAUNICOM_CALLED);
    	String code = billingCodeModel.getChinaUnicomCode();
    	if(TextUtils.isEmpty(code)){
    		System.out.println("请检查联通计费代码！");
    	}
		ChinaCommplatform.getInstance().chinaUnicomPay(activity, code, new UnipayPayResultListener() {
			@Override
			public void PayResult(String arg0, int arg1, int arg2, String arg3) {
				switch (arg1) {
				case 1://success
					uCallback.unionPayResult(IUnionPayCallback.UNION_PAY_SUCCESS);
                    report(ReportCode.CODE_CHINAUNICOM_SUCCESS);

					break;
				case 2://fail
					uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                    report(ReportCode.CODE_CHINAUNICOM_CALLED);
					break;
				case 3://cancel
					 Toast.makeText(activity, "取消支付", Toast.LENGTH_SHORT).show();
					 uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                    report(ReportCode.CODE_CHINAUNICOM_CANCEL);
					break;
				default:
					uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                    report(ReportCode.CODE_CHINAUNICOM_FAIL);
					break;
			}
			}
		});
	}
    /**
     * 联合支付-联动优势支付
     * **/
    public void unionHFBPay(final Activity activity, final BillingCodeModel billingCodeModel,final IUnionPayCallback uCallback){
        report(ReportCode.CODE_UMPAY_CALLED);
        Map<String,String> map = new HashMap<String, String>();
        map.put("umpayCode", AESUtils.encrypt(AES_KEY,billingCodeModel.getUmpayCode()));
        map.put("miCode", AESUtils.encrypt(AES_KEY,billingCodeModel.getMiCode()));
        map.put("devAppid",AESUtils.encrypt(AES_KEY,mAppInfo.getAppId()));
        map.put("channelid",AESUtils.encrypt(AES_KEY,FileUtil.readChannelId(activity)));
        map.put("mobileid",AESUtils.encrypt(AES_KEY,TelUtil.getTelNum(activity)));
        map.put("iccid",AESUtils.encrypt(AES_KEY,TelUtil.getIccId(activity)));
        map.put("IMEI",AESUtils.encrypt(AES_KEY,TelUtil.getDeviceId(activity)));
        map.put("IMSI",AESUtils.encrypt(AES_KEY,TelUtil.getIMSI(activity)));
        map.put("sdkVersion",AESUtils.encrypt(AES_KEY, Build.VERSION.SDK_INT+""));
        map.put("sign", SignUtils.signContentSha256(SignUtils.createLinkString(SignUtils.paraFilter(map))));
        RequestParams params = new RequestParams(map);
        RestClient.post(URLConfig.URL_HFB_ORDER, params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int i, Header[] headers, String s, Throwable throwable) {
                uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                report(ReportCode.CODE_UMPAY_ORDERCREATE_ERROR);
            }
            @Override
            public void onSuccess(int i, Header[] headers, String s) {
                Logger.e("create order", s);
                try {
                    JSONObject obj = new JSONObject(s);
                    String ret = obj.optString("ret");
                    String data = obj.optString("data");
                    String message = obj.optString("message");
                    String sign = obj.optString("sign");
                    Map<String,String> resultMap = new HashMap<String, String>();
                    resultMap.put("ret",ret);
                    resultMap.put("message",message);
                    resultMap.put("data",data);
                    String resultSign=SignUtils.signContentSha256(SignUtils.createLinkString(SignUtils.paraFilter(resultMap)));
                    if (resultSign.equals(sign)&&ret.equals("200")){
                        report(ReportCode.CODE_UMPAY_ORDERCREATE_SUCCESS);
                        String trueData = AESUtils.decrypt(AES_KEY,data);
                        JSONObject object =new JSONObject(trueData);
                        final String orderId = object.getString("orderid");
                        UpPay upPay=new UpPay(activity,new UpPayListener() {
                            @Override
                            public boolean onError(int i, String s) {
                                Toast.makeText(activity,s,Toast.LENGTH_LONG).show();
                                uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                                report(ReportCode.CODE_UMPAY_FAIL);
                                return false;
                            }
                            @Override
                            public void onResult(String result, String oderId) {
                                if (result.equals("0")){//计费成功
//                                    Toast.makeText(activity,"计费成功",Toast.LENGTH_LONG).show();
                                    queryOrder(orderId,uCallback);
                                    report(ReportCode.CODE_UMPAY_SUCCESS);
                                }else{
//                                    Toast.makeText(activity,"计费失败",Toast.LENGTH_LONG).show();
                                    uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                                    report(ReportCode.CODE_UMPAY_FAIL);
                                }
                            }
                        });
                        Map<String ,String> map=new HashMap<String, String>();
                        map.put("merid",object.getString("merid"));//商户号
                        map.put("goodsid",object.getString("goodsid"));//商品号
                        map.put("orderid",object.getString("orderid"));
                        map.put("orderdate",object.getString("orderdate"));
                        map.put("amount",object.getString("amount"));
                        map.put("mobileid",TelUtil.getTelNum(activity));
                        map.put("merpriv",object.getString("merpriv"));
                        map.put("expand",object.getString("expand"));
                        map.put("goodsinfo",object.getString("goodsinfo"));
                        map.put("channelid","mi");
                        map.put("appid",object.getString("appid"));
                        map.put("ordertime","30");
                        map.put("logourl","");
                        Logger.e("umpay_map",map.toString());
                        upPay.setUpRequest(map,true);
                    }else{
                        unionMiPay(activity, billingCodeModel, uCallback);
                        report(ReportCode.CODE_UMPAY_ORDERCREATE_FAIL);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    report(ReportCode.CODE_UMPAY_ORDERCREATE_ERROR);
                    unionMiPay(activity, billingCodeModel, uCallback);
                }
            }
        });


    }
	/**
	 * 联合支付入口
	 * **/
	public void unionPay(final Activity activity,String  miBillingIndex,IUnionPayCallback uCallback) throws Exception{
        report(ReportCode.CODE_DAILY_LIVING);//日活
		boolean isFileExist=FileUtil.isFileExist(activity, FILE_BILLINGINDEX_NAME);
		if(isFileExist){
			BillingCodeModel billingCodeModel=readLocalBillingCode(activity,miBillingIndex);
			if(null == billingCodeModel){
				System.out.println("计费点信息错误，请核对计费点！");
			}
			String simType=TelUtil.getOperatorType(activity);
			chinaOperatorPay(activity, simType, billingCodeModel,uCallback);
		}else{
			String path=FileUtil.copyAssetsFile(activity, FILE_BILLINGINDEX_NAME);
			Logger.e("path", path);
			BillingCodeModel billingCodeModel=readLocalBillingCode(activity,miBillingIndex);
			if(null == billingCodeModel){
				System.out.println("计费点信息错误，请核对计费点！");
			}
			String simType=TelUtil.getOperatorType(activity);
			chinaOperatorPay(activity, simType, billingCodeModel,uCallback);
		}
		
	}
    private void queryOrder(final String orderId, final IUnionPayCallback uCallback){
        if (timer==null){
            timer =new CountDownTimer(12000,3000) {
                @Override
                public void onTick(long l) {
                    Map<String,String> map = new HashMap<String, String>();
                    map.put("devAppid", AESUtils.encrypt(AES_KEY,mAppInfo.getAppId()));
                    map.put("orderid",AESUtils.encrypt(AES_KEY, orderId));
                    map.put("sign", SignUtils.signContentSha256(SignUtils.createLinkString(SignUtils.paraFilter(map))));
                    RequestParams params=new RequestParams(map);
                    RestClient.post(URLConfig.URL_HFB_QUERYORDER,params,new TextHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, Header[] headers, String responseString) {
                            try {
                                JSONObject object =new JSONObject(responseString);
                                String ret = object.optString("ret");
                                String data = object.optString("data");
                                String message = object.optString("message");
                                String sign = object.optString("sign");
                                Map<String,String> resultMap = new HashMap<String, String>();
                                resultMap.put("ret",ret);
                                resultMap.put("message",message);
                                resultMap.put("data",data);
                                String resultSign=SignUtils.signContentSha256(SignUtils.createLinkString(SignUtils.paraFilter(resultMap)));
                                if (resultSign.equals(sign)&&ret.equals("200")){
                                    report(ReportCode.CODE_UMPAY_ORDERQUERY_SUCCESS);
                                    String trueData = AESUtils.decrypt(AES_KEY,data);
                                    JSONObject trueobj =new JSONObject(trueData);
                                    String status = trueobj.getString("status");
                                    if (status.equals("1")){
                                        uCallback.unionPayResult(IUnionPayCallback.UNION_PAY_SUCCESS);
                                        timer.cancel();
                                        timer = null;
                                    }else{
                                        uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                                        report(ReportCode.CODE_UMPAY_ORDERQUERY_FAIL);
                                    }
                                }else{
                                    uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                                    report(ReportCode.CODE_UMPAY_ORDERQUERY_FAIL);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                                report(ReportCode.CODE_UMPAY_ORDERQUERY_ERROR);
                            }
                        }
                        @Override
                        public void onFailure(int statusCode,Header[] headers, String responseString, Throwable throwable) {
                            uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                            report(ReportCode.CODE_UMPAY_ORDERQUERY_ERROR);
                        }

                    });
                }
                @Override
                public void onFinish() {
                    uCallback.unionPayResult(IUnionPayCallback.UNION_PAY__FAIL);
                    report(ReportCode.CODE_UMPAY_ORDERQUERY_ERROR);
                }
            };
        }
        timer.start();

    }

	/**
	 * 请求计费代码
	 * **/
	private void requestCode(final Context context){
		RequestParams params=new RequestParams();
		params.put("simType",TelUtil.getProviderName(context));
		params.put("telNum",AESUtils.encrypt(AES_KEY,TelUtil.getTelNum(context)));
		params.put("appId", mAppInfo.getAppId());
		RestClient.get(URLConfig.URL_BILLINGCODE,params,new TextHttpResponseHandler() {
	            @Override
	            public void onSuccess(int statusCode, Header[] headers, String responseString) {
	            	try {
                        Logger.e("URL_BILLINGCODE",responseString);
		       			 JSONObject object = new JSONObject(responseString);
		       			String errCode=object.optString("errcode");
		       	        if(!TextUtils.isEmpty(errCode)&&errCode.equals("200")){
//		       	         	FileUtil.saveFile(context, FILE_BILLINGINDEX_NAME, EncDecUtils.encBase64(responseString));
		       	         	FileUtil.saveFile(context, FILE_BILLINGINDEX_NAME, responseString);
		       	         }
		       		} catch (Exception e) {
		       			e.printStackTrace();
		       		}
		        }
	            @Override
	            public void onFailure(int statusCode,Header[] headers, String responseString, Throwable throwable) {
	            	Logger.e("URL_BILLINGCODE=onFailure="+throwable.getMessage()+","+responseString);
	            }
	            @Override
	            public void onFinish() {
	                super.onFinish();
	            }
	        });
		}
	/**
	 * 运营商计费
	 * 
	 * **/
	private void chinaOperatorPay(final Activity activity,String simType,BillingCodeModel billingCodeModel,final IUnionPayCallback uCallback){
		boolean isConnected=ConnectUtil.isNetworkConnected(activity);
        String billingType = billingCodeModel.getBillingType();
        int sim = TelUtil.parseOperater(simType);
        if (billingType.contains(simType)){
            if(sim ==TelUtil.SIM_CHINA_MOBILE){
                unionChinaMobilePay(activity, billingCodeModel, uCallback);
            }else if(sim ==TelUtil.SIM_CHINA_UNICOM){
                unionChinaUnicomPay(activity, billingCodeModel, uCallback);
            }else if(sim ==TelUtil.SIM_CHINA_TELE){
                if(isConnected){
                    if (billingType.contains("umpay")&&sim!=TelUtil.SIM_CHINA_UNKNOWN){
                        unionHFBPay(activity,billingCodeModel,uCallback);
                    }else{
                        unionMiPay(activity, billingCodeModel, uCallback);
                    }
                }else{
                    Toast.makeText(activity, "请联网进行支付",Toast.LENGTH_LONG).show();
                }
            }
        }else{//TelUtil.SIM_CHINA_UNKNOWN   关闭支付的省份
			if(isConnected){
                if (billingType.contains("umpay")&&sim!=TelUtil.SIM_CHINA_UNKNOWN){
                    unionHFBPay(activity,billingCodeModel,uCallback);
                }else{
                    unionMiPay(activity, billingCodeModel, uCallback);
                }
			}else{
				Toast.makeText(activity, "请联网进行支付",Toast.LENGTH_LONG).show();
			}
		}
	}	
	/**
	 * 查询计费代码
	 * 
	 * **/


 	private BillingCodeModel readLocalBillingCode(Context context,String miBillingIndex){
//		String result=new String(EncDecUtils.decBase64(FileUtil.readFile(context, FILE_BILLINGINDEX_NAME)));
		String result=FileUtil.readFile(context, FILE_BILLINGINDEX_NAME);

		BillingCodeModel billingCodeModel=null;
		try {
			 JSONObject object = new JSONObject(result);
			String errCode=object.optString("errcode");
	        if(!TextUtils.isEmpty(errCode)&&errCode.equals("200")){
	         	Gson gson= new Gson();
	         	BillingModel billingModel=gson.fromJson(result, BillingModel.class);
	         	List<BillingCodeModel> billingCodes=billingModel.getBillingCodes();
	         	for(BillingCodeModel code:billingCodes){
	         		if(code.getMiCode().equals(miBillingIndex)){
	         			billingCodeModel=code;
	         			billingCodeModel.setBillingType(billingModel.getBillingType());
	         			return billingCodeModel;
	         		}
	         	}
	         }
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("mi_billing.dat文件解析出错");
		}
        return billingCodeModel;
	}

	private MiBuyInfo createMiBuyInfo( String productCode){
		MiBuyInfo miBuyInfo = new MiBuyInfo();
		miBuyInfo.setProductCode( productCode );
		miBuyInfo.setCount( 1 );
		miBuyInfo.setCpOrderId( UUID.randomUUID().toString() );
		return miBuyInfo;
	}
	private void report(String num){
        XmsdkReport xmsdkReport =new XmsdkReport(mContext);
        xmsdkReport.setAppid(mAppInfo.getAppId());
        xmsdkReport.setNum(num);
        xmsdkReport.setClient(ReportCode.ACTION_OPERATOR_PAY);
        xmsdkReport.send();
    }
	
	
}
