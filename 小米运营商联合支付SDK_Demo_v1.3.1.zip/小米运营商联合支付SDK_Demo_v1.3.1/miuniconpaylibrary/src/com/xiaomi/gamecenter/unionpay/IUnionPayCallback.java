package com.xiaomi.gamecenter.unionpay;

public interface IUnionPayCallback {
	public static final int UNION_PAY_SUCCESS=101;
	public static final int UNION_PAY__FAIL=102;
	public void unionPayResult(int resultCode);
}
