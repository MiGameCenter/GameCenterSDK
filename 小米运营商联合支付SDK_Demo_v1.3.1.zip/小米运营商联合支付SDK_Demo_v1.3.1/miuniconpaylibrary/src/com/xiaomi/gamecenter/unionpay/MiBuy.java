package com.xiaomi.gamecenter.unionpay;

import android.app.Activity;
import android.os.RemoteException;

import com.xiaomi.gamecenter.sdk.MiCommplatform;
import com.xiaomi.gamecenter.sdk.MiErrorCode;
import com.xiaomi.gamecenter.sdk.OnLoginProcessListener;
import com.xiaomi.gamecenter.sdk.OnPayProcessListener;
import com.xiaomi.gamecenter.sdk.entry.MiAccountInfo;
import com.xiaomi.gamecenter.sdk.entry.MiBuyInfo;

public final class MiBuy
{
	private static MiBuy instance = new MiBuy();

	private Object _miBuyLock_ = new Object();

	private final static long LOGINWAITTIME = 5 * 60 * 1000;

	private final static long BUYWAITTIME = 2 * 60 * 1000;

	private int miBuyCode = MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_FAILURE;
	
	private int miLoginCode = MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_LOGIN_FAIL;

	public MiBuy()
	{

	}

	public static MiBuy getInstance()
	{
		return instance;
	}

	public synchronized int buyForMiUniPay( final Activity activity, final MiBuyInfo mibuyInfo )
	{
		if ( null == activity || null == mibuyInfo )
			return MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_FAILURE;

		MiAccountInfo accountInfo = MiCommplatform.getInstance().getAccountInfo();
		
		if(null == accountInfo)
		{
			miBuyLogin( activity );
			
			if( miLoginCode != MiErrorCode.MI_XIAOMI_PAYMENT_SUCCESS )
				return MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_FAILURE;
		}
		
		activity.runOnUiThread( new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					MiCommplatform.getInstance().miUniPay( activity, mibuyInfo, new OnPayProcessListener()
						{
							@Override
							public void finishPayProcess( int code )
							{
								miBuyCode = code;

								synchronized ( _miBuyLock_ )
								{
									_miBuyLock_.notifyAll();
								}
							}
						} );
				}
				catch ( RemoteException e )
				{
					e.printStackTrace();
				}
			}
		} );
		synchronized ( _miBuyLock_ )
		{
			try
			{
				_miBuyLock_.wait( BUYWAITTIME );
			}
			catch ( InterruptedException e )
			{
				e.printStackTrace();
			}
		}
		return miBuyCode;
	}

	private void miBuyLogin( Activity activity )
	{
		MiCommplatform.getInstance().miLogin( activity, mLoginListener );
		synchronized ( _miBuyLock_ )
		{
			try
			{
				_miBuyLock_.wait( LOGINWAITTIME );
			}
			catch ( InterruptedException e )
			{
				e.printStackTrace();
			}
		}
	}

	private OnLoginProcessListener mLoginListener = new OnLoginProcessListener()
	{
		@Override
		public void finishLoginProcess( int code, MiAccountInfo account )
		{
			if ( MiErrorCode.MI_XIAOMI_PAYMENT_SUCCESS == code )
			{
				if ( null != account )
				{
					MiCommplatform.getInstance().updateMiAppInfo( account );
					miLoginCode = code;
				}
			}
			synchronized ( _miBuyLock_ )
			{
				_miBuyLock_.notifyAll();
			}
		}
	};
}
