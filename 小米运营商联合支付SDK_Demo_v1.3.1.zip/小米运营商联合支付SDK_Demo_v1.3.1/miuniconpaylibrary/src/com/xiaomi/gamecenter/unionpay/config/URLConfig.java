package com.xiaomi.gamecenter.unionpay.config;

public class URLConfig {
	private static final String HOME_TEST="http://migc.wali.com/api/v1/";
	private static final String UMPAY_TEST="http://10.21.109.52/";

	private static final String HOME="http://mis.migc.xiaomi.com/api/biz/";
	public static final String URL_BILLINGCODE=HOME+"game/payments.do";
	public static final String URL_PAY_STATICS="https://data.game.xiaomi.com/log/";


    private static final String UMPAY_RELEASE="http://umpay.g.mi.com/";
    public static final String URL_HFB_ORDER = UMPAY_RELEASE + "order/create";
    public static final String URL_HFB_QUERYORDER = UMPAY_RELEASE + "order/query";
}
