package com.xiaomi.gamecenter.unionpay.http;

import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.xiaomi.gamecenter.unionpay.log.Logger;

import java.net.URI;

public class RestClient {
	public static AsyncHttpClient client = new AsyncHttpClient();
    public static void get(String url, RequestParams params,
                           AsyncHttpResponseHandler responseHandler) {
        client.get(url, params, responseHandler);
        Logger.e("RestClient-->get", client.getUrlWithQueryString(false, url, params));
    }

    public static void post(String url, RequestParams params,
                            AsyncHttpResponseHandler responseHandler) {
    	client.post(url, params, responseHandler);
        Logger.e("RestClient-->post", client.getUrlWithQueryString(false, url, params));
    }
    
   
}
