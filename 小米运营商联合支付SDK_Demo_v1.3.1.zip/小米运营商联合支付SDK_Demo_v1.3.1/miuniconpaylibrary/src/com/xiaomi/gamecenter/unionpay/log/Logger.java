package com.xiaomi.gamecenter.unionpay.log;

import android.util.Log;

public class Logger {


	/**
	 * log switch
	 */
	 ////////////==============打包请注意=============/////////////////////////////////////////
	public final static boolean printLog = false ;
	private final static int VERBOSE = 1;
	private final static int DEBUG = 2;
	private final static int INFO = 3;
	private final static int WARNING = 4;
	private final static int ERROR = 5;

	/**
	 * current level for log 1. verbose,debug,info,warning,error 2.
	 * debug,info,warning,error 3. info,warning,error 4. warning,error 5. error
	 */
	private final static int currentLevel = VERBOSE;

	/**
	 * verbose
	 */
	public final static boolean V = printLog && (currentLevel < DEBUG);

	/**
	 * debug
	 */
	public final static boolean D = printLog && (currentLevel < INFO);

	/**
	 * info
	 */
	public final static boolean I = printLog && (currentLevel < WARNING);

	/**
	 * warning
	 */
	public final static boolean W = printLog && (currentLevel < ERROR);

	/**
	 * error
	 */
	public final static boolean E = printLog;

	public static void d(String tag, String msg) {
		if (!D) {
			return;
		}
		Log.d(tag, msg + "");
	}

	public static void d(String tag, String msg, Throwable tr) {
		if (!D) {
			return;
		}
		Log.d(tag, msg + "", tr);
	}

	public static void v(String tag, String msg) {
		if (!V) {
			return;
		}
		Log.v(tag, msg + "");
	}

	public static void v(String tag, String msg, Throwable tr) {
		if (!V) {
			return;
		}
		Log.v(tag, msg + "", tr);
	}

	public static void i(String tag, String msg) {
		if (!I) {
			return;
		}
		Log.i(tag, msg + "");
	}

	public static void i(String tag, String msg, Throwable tr) {
		if (!I) {
			return;
		}
		Log.i(tag, msg + "", tr);
	}

	public static void w(String tag, String msg) {
		if (!W) {
			return;
		}
		Log.w(tag, msg + "");
	}

	public static void w(String tag, String msg, Throwable tr) {
		if (!W) {
			return;
		}
		Log.w(tag, msg + "", tr);
	}

	public static void e(String tag, String msg) {
		if (!E) {
			return;
		}
		Log.e(tag, msg + "");
	}

	public static void e(Throwable tr) {
		if (!E) {
			return;
		}
		if (tr != null)
			tr.printStackTrace();
	}
	public static void e(String s) {
		Logger.e("jdlog", s);
	}

	public static void e(String tag, String msg, Throwable tr) {
		if (!E) {
			return;
		}
		Log.e(tag, msg + "", tr);
	}

}
