package com.xiaomi.gamecenter.unionpay.model;

import java.io.Serializable;

import com.google.gson.annotations.Expose;

public class BillingCodeModel implements Serializable{
	@Expose
	private String miCode;
	@Expose
	private String chinaMobileCode;
	@Expose
	private String chinaUnicomCode;
	@Expose
	private String chinaTeleCode;
    @Expose
    private String umpayCode;

	private String billingType;
	
	
	public BillingCodeModel() {
		super();
	}


    public String getMiCode() {
        return miCode;
    }

    public void setMiCode(String miCode) {
        this.miCode = miCode;
    }

    public String getChinaMobileCode() {
        return chinaMobileCode;
    }

    public void setChinaMobileCode(String chinaMobileCode) {
        this.chinaMobileCode = chinaMobileCode;
    }

    public String getChinaUnicomCode() {
        return chinaUnicomCode;
    }

    public void setChinaUnicomCode(String chinaUnicomCode) {
        this.chinaUnicomCode = chinaUnicomCode;
    }

    public String getChinaTeleCode() {
        return chinaTeleCode;
    }

    public void setChinaTeleCode(String chinaTeleCode) {
        this.chinaTeleCode = chinaTeleCode;
    }

    public String getUmpayCode() {
        return umpayCode;
    }

    public void setUmpayCode(String umpayCode) {
        this.umpayCode = umpayCode;
    }

    public String getBillingType() {
        return billingType;
    }

    public void setBillingType(String billingType) {
        this.billingType = billingType;
    }
}
