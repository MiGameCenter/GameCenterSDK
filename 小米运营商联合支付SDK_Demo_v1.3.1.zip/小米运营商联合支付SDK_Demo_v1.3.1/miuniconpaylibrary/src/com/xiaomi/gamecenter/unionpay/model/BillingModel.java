package com.xiaomi.gamecenter.unionpay.model;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;

public class BillingModel implements Serializable{
	@Expose
	private String billingType;
	@Expose
	private List<BillingCodeModel> billingCodes;
	public BillingModel() {
		super();
	}
	public String getBillingType() {
		return billingType;
	}
	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}
	public List<BillingCodeModel> getBillingCodes() {
		return billingCodes;
	}
	public void setBillingCodes(List<BillingCodeModel> billingCodes) {
		this.billingCodes = billingCodes;
	}
	
	
}
