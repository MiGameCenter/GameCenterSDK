package com.xiaomi.gamecenter.unionpay.report;

public class ReportCode {
    public static final String ACTION_OPERATOR_PAY = "operator_pay";

    public static final String CODE_DAILY_LIVING="1000";

	public static final String CODE_CHINAUNICOM_CALLED="101";
	public static final String CODE_CHINAUNICOM_SUCCESS="102";
	public static final String CODE_CHINAUNICOM_FAIL="103";
	public static final String CODE_CHINAUNICOM_CANCEL="104";
	
	public static final String CODE_CHINAMOBILE_CALLED="201";
	public static final String CODE_CHINAMOBILE_SUCCESS="202";
	public static final String CODE_CHINAMOBILE_FAIL="203";
	public static final String CODE_CHINAMOBILE_CANCEL="204";
	
	public static final String CODE_MI_CALLED="301";
	public static final String CODE_MI_SUCCESS="302";
	public static final String CODE_MI_FAIL="303";

    public static final String CODE_UMPAY_CALLED="401";
    public static final String CODE_UMPAY_SUCCESS="402";
    public static final String CODE_UMPAY_FAIL="403";
    public static final String CODE_UMPAY_ORDERQUERY_SUCCESS="404";
    public static final String CODE_UMPAY_ORDERQUERY_FAIL="405";
    public static final String CODE_UMPAY_ORDERQUERY_ERROR="406";
    public static final String CODE_UMPAY_ORDERCREATE_SUCCESS="407";
    public static final String CODE_UMPAY_ORDERCREATE_FAIL="408";
    public static final String CODE_UMPAY_ORDERCREATE_ERROR="409";

}
