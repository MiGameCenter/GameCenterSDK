package com.xiaomi.gamecenter.unionpay.util;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.*;

/**
 * Created by chenhaitao on 15-12-4.
 */
public class AESUtils {
    public static String encrypt(String strKey, String strIn){
        if (null==strIn||strIn.equals("")){
            return "";
        }
        byte[] encrypted = new byte[0];
        try {
            SecretKeySpec skeySpec = getKey(strKey);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec("0102030405060708".getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
            encrypted = cipher.doFinal(strIn.getBytes("UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Base64Utils().encode(encrypted);
    }

    public static String decrypt(String strKey, String strIn) {
        String originalString = null;
        try {
            SecretKeySpec skeySpec = getKey(strKey);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec("0102030405060708".getBytes());
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] encrypted1 = new Base64Utils().decode(strIn);

            byte[] original = cipher.doFinal(encrypted1);
            originalString = new String(original);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return originalString;
    }

    private static SecretKeySpec getKey(String strKey) throws Exception {
        byte[] arrBTmp = strKey.getBytes("UTF-8");
        byte[] arrB = new byte[16]; // 创建一个空的16位字节数组（默认值为0）
        for (int i = 0; i < arrBTmp.length && i < arrB.length; i++) {
            arrB[i] = arrBTmp[i];
        }
        SecretKeySpec skeySpec = new SecretKeySpec(arrB, "AES");
        return skeySpec;
    }

    public static String encrypt(String strIn) {

        String code = null;
        try {
            Random rand = new Random((new Date()).getTime());
            int num = rand.nextInt(10);
            String key = num + UUID.randomUUID().toString().replace("-", "").substring(0, num);
            code = AESUtils.encrypt(key, strIn);
            code = key +  code;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return code;
    }

    public static String decrypt(String strIn) {
        String code = null;
        try {
            int num = Integer.valueOf(strIn.substring(0, 1));
            String key = strIn.substring(1,num+1);
            key = num + key;
            strIn = strIn.substring(num + 1);
            code = AESUtils.decrypt(key, strIn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return code;
    }
    public static void main(String... args) throws Exception {
        String key="clientkey";
        String content="2882303761517402635";
        String encContent=encrypt(key,content);

        System.out.println(encContent);
        String result=decrypt(key,"oYeE3b1RVTL6tSkO0iK/NXE02FxbRG9YHTlPK6129nQ=");
        System.out.println(result);

    }


}
