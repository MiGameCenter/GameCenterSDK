package com.xiaomi.gamecenter.unionpay.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;

import org.json.JSONObject;

import cz.msebera.android.httpclient.util.EncodingUtils;

public class FileUtil {
	public static boolean isFileExist(Context context,String fileName){
		File file=new File(context.getCacheDir(), fileName);
		if(file.exists()){
			return true;
		}
		return false;
	}
	public static boolean saveFile(Context context,String fileName,String data){
		try{   
	        FileOutputStream fout =context.openFileOutput(fileName,context.MODE_PRIVATE);   
	        byte [] bytes = data.getBytes();   
	        fout.write(bytes);   
	        fout.close();   
	      }catch(Exception e){   
	        e.printStackTrace();   
	        return false;
	      }   
	      return true; 
	}
	
	public static String readFile(Context context,String fileName){
//		File file = new File(context.getFilesDir(), fileName);  
	        String res = ""; 
	        try { 
	            FileInputStream fin = context.openFileInput(fileName); 
	            int length = fin.available(); 
	            byte[] buffer = new byte[length]; 
	            fin.read(buffer); 
	            res = EncodingUtils.getString(buffer, "UTF-8"); 
	            fin.close(); 
	        } catch (Exception e) { 
	            e.printStackTrace(); 
	        } 
	        return res; 
	    } 
//        try {  
//            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));  
//            String data = br.readLine();  
//            return data;  
//        } catch (Exception e) {  
//        	e.printStackTrace();
//            return "";  
//        }  
//	}
	public static String copyAssetsFile(Context context,String fileName){
		File path = context.getFilesDir();
        File fs =   new File(path,fileName);
        if(!fs.exists()){
            InputStream myInput;  
            OutputStream myOutput;
			try {
				myOutput = new FileOutputStream(fs);
				myInput = context.getAssets().open(fileName);  
				  byte[] buffer = new byte[1024];  
		            int length = myInput.read(buffer);
		            while(length > 0)
		            {
		                myOutput.write(buffer, 0, length); 
		                length = myInput.read(buffer);
		            }
		             
		            myOutput.flush();  
		            myInput.close();  
		            myOutput.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
        }
        return fs.getAbsolutePath();    
	}

    public static String readChannelId(Context context){
        String channel="meng_100_1_android";//默认值
        try {
            InputStream is = context.getAssets().open("meng.sdk.dat");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String result = new String(buffer, "utf-8");
            JSONObject object =new JSONObject(result);
            channel = object.getString("cid");
        } catch (Exception e) {
            e.printStackTrace();
            return channel;
        }
        return channel;
    }
	
}
