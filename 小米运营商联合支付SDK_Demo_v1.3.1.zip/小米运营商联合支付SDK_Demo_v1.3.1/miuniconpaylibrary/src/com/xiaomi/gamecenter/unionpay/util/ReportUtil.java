package com.xiaomi.gamecenter.unionpay.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Random;
import java.util.UUID;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

public class ReportUtil {

	public static String getDeviceId(Context context) {
		String deviceId = "";
		if (isPad()) {
			deviceId = ZSIMInfo.getMacAddressNew(context);
			if (!TextUtils.isEmpty(deviceId)) {
				deviceId = ZSIMInfo.SHA1(deviceId);
			} else {
				deviceId = "";
			}
		} else {
			deviceId = ZSIMInfo.getSha1DeviceID(context);
		}
		return deviceId;
	}

	public static int getVersionCode(Context context) {
		PackageInfo pinfo;
		try {
			pinfo = context.getPackageManager()
					.getPackageInfo(context.getPackageName(),
							PackageManager.GET_CONFIGURATIONS);
			return pinfo.versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static String getSIMOperatorName(Context context) {
		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		String operator = tm.getSimOperator();
		if ("46000".equals(operator) || "46002".equals(operator)
				|| "45412".equals(operator) || "46007".equals(operator)) {
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_CMCC);
			return "CMCC";
		} else if ("46001".equals(operator) || "46006".equals(operator)) {
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_UNICOM);
			return "UNICOM";
		} else if ("46003".equals(operator)) {
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_UNICOM);
			return "TELECOM";
		} else {
			return "UNKNOW";
		}
	}

	public static String get3gMacAddress(Context context) {
		String _3gmac = null;
		WifiManager wifi = (WifiManager) context
				.getSystemService(Context.WIFI_SERVICE);
		if (wifi != null && wifi.isWifiEnabled()) {
			_3gmac = "";
		} else {
			try {
				File dir = new File("/sys/class/net/");
				File file[] = dir.listFiles();
				FileInputStream fip = null;
				int index = -1;
				for (int i = 0; i < file.length; i++) {
					if (file[i].isDirectory()
							&& !file[i].getName().equalsIgnoreCase("lo")) {
						try {
							fip = new FileInputStream(file[i].getPath()
									+ "/carrier");
							fip.read();// 只要可读 那么该目录即是当前的活动的网络
						} catch (Exception e) {
							// e.printStackTrace();
							continue;
						} finally {
							if (fip != null) {
								try {
									fip.close();
								} catch (IOException e) {
									// e.printStackTrace();
								}
								fip = null;
							}
						}

						index = i;
						break;
					}
				}

				if (-1 != index) {
					try {
						fip = new FileInputStream("/sys/class/net/"
								+ file[index].getName() + "/address");
						int len = fip.available();
						if (len > 0) {
							byte[] buffer = new byte[len];
							fip.read(buffer);
							_3gmac = new String(buffer);
							buffer = null;
							int pos = _3gmac.indexOf("\n");// 去掉换行符
							if (pos != -1) {
								_3gmac = _3gmac.substring(0, pos);
								if (0 == _3gmac.length()) {
									_3gmac = null;
								}
							}
						}
					} catch (Exception e) {
						// e.printStackTrace();
					} finally {
						if (fip != null) {
							try {
								fip.close();
							} catch (IOException e) {
								// e.printStackTrace();
							}
							fip = null;
						}
					}
				}

				return upperCase(_3gmac);
			} catch (Exception e) {
				// e.printStackTrace();
			}
		}
		return null;
	}
	
	public static String get_device_agent_(Context c) {

		StringBuffer sb = new StringBuffer();
		sb.append(getSystemProperties("ro.product.manufacturer"));
		sb.append("|");
		sb.append(getSystemProperties("ro.product.model"));
		sb.append("|");
		sb.append(getOSVersion());
		sb.append("|");
		sb.append(getSystemProperties("ro.build.display.id"));
		sb.append("|");
		sb.append(getSystemProperties("ro.build.version.sdk"));
		sb.append("|");
		sb.append(getSystemProperties("ro.product.device"));
		return sb.toString();
	}
	private static String getOSVersion(){
        StringBuffer sb = new StringBuffer();
        sb.append(getSystemProperties("ro.build.version.release"));
        sb.append("_");
        if (isAlphaBuild()) {
            sb.append("alpha");
        } else if (isDevelopmentVersion()) {
            sb.append("develop");
        } else if (isStableVersion()) {
            sb.append("stable");
        } else {
        	sb.append("na");
        }
        sb.append("_");
        sb.append(Build.VERSION.INCREMENTAL);
        return sb.toString();
        
    }
	 /**
     * 是否为MIUI 体验版
     * 从miui.os.Build类里拷贝的代码
     * @return
     */
    private static boolean isAlphaBuild(){
    	try {
			return getSystemProperties("ro.product.mod_device").endsWith("_alpha");
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return false;
    }
    
    /**
     * 是否为MIUI 开发版
     * 从miui.os.Build类里拷贝的代码
     * @return
     */
    private static boolean isDevelopmentVersion(){
    	try {
			String increment = Build.VERSION.INCREMENTAL;
			if(!TextUtils.isEmpty(increment)){
				if(increment.matches("\\d+.\\d+.\\d+(-internal)?")){
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return false;
    }
    
    /**
     * 是否为MIUI 稳定版
     * 从miui.os.Build类里拷贝的代码
     * @return
     */
    private static boolean isStableVersion(){
    	if("user".equals(Build.TYPE)){
    		if(!isDevelopmentVersion()){
    			return true;
    		}
    	}
    	return false;
    }
	private static String getSystemProperties(String prop) {
		String output = "";
		try {
			Class<?> sp = Class.forName("android.os.SystemProperties");
			java.lang.reflect.Method get = sp.getMethod("get", String.class);
			output = (String) get.invoke(null, prop);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}
	public static String getRandomIndex() {
		UUID uuid = UUID.randomUUID();
		return MD5.getMD5_16(uuid.toString().getBytes());
	}

	public static int getRandom(int index) {
		return new Random().nextInt(index) + 1;
	}

	private static boolean isPad() {
		try {
			Class ownerClass = Class.forName("miui.os.Build");
			Field field = ownerClass.getField("IS_TABLET");
			return (Boolean) field.get(ownerClass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private static String upperCase(String s) {
		return s.replace(":", "").toUpperCase();
	}
}
