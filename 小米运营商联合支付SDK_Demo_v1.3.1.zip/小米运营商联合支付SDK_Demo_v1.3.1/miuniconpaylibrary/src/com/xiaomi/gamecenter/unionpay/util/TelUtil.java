package com.xiaomi.gamecenter.unionpay.util;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.unicom.dcLoader.Utils;
import com.unicom.dcLoader.Utils.SimType;

public class TelUtil {
	public final static int SIM_CHINA_UNKNOWN=-1;
	public final static int SIM_CHINA_UNICOM=1;
	public final static int SIM_CHINA_MOBILE=2;
	public final static int SIM_CHINA_TELE=3;
	public static String getTelNum(Context context){
        TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceid = tm.getDeviceId();//获取智能设备唯一编号
        String te1  = tm.getLine1Number();//获取本机号码
        String iccid = tm.getSimSerialNumber();//获得SIM卡的序号  ICCID
        String imsi = tm.getSubscriberId();//得到用户Id
        if (TextUtils.isEmpty(te1)){
            return "";
        }else{
            if (te1.length()>14){
                return "";
            }
            if (te1.startsWith("+86")){
                te1=te1.substring(3,te1.length());
            }
        }
		return te1;
	}
    public static String getDeviceId(Context context){
        TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceid = tm.getDeviceId();//获取智能设备唯一编号
        String te1  = tm.getLine1Number();//获取本机号码
        String iccid = tm.getSimSerialNumber();//获得SIM卡的序号  ICCID
        String imsi = tm.getSubscriberId();//得到用户Id
        if (TextUtils.isEmpty(deviceid)){
            return "";
        }
        return deviceid;
    }
    public static String getIccId(Context context){
        TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceid = tm.getDeviceId();//获取智能设备唯一编号
        String te1  = tm.getLine1Number();//获取本机号码
        String iccid = tm.getSimSerialNumber();//获得SIM卡的序号  ICCID
        String imsi = tm.getSubscriberId();//得到用户Id
        if (TextUtils.isEmpty(iccid)){
            return "";
        }
        return iccid;
    }
    public static String getIMSI(Context context){
        TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceid = tm.getDeviceId();//获取智能设备唯一编号
        String te1  = tm.getLine1Number();//获取本机号码
        String iccid = tm.getSimSerialNumber();//获得SIM卡的序号  ICCID
        String imsi = tm.getSubscriberId();//得到用户Id
        return imsi;
    }
	public static String getProviderName(Context context){
		TelephonyManager telManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE); 
		String operator = telManager.getSimOperator();
		String name="unknown";
		if(operator!=null){ 
			if(operator.equals("46000") || operator.equals("46002")|| operator.equals("46007")){
				name="chinamobile";
			}else if(operator.equals("46001")){
				name="chinaunicom";
			}else if(operator.equals("46003")){
				name="chinatele";
			} 
		}
		return name;

	}
	public static String getOperatorType(Context context){
//	    int result=SIM_CHINA_UNKNOWN;
        String simType =getProviderName(context);
//           if(simType.equals("chinamobile")){
//			   result= SIM_CHINA_MOBILE;
//		   }else if(simType.equals("chinaunicom")){
//			   result = SIM_CHINA_UNICOM;
//		   }else if(simType.equals("chinatele")){
//			   result = SIM_CHINA_TELE;
//		   }
	    return simType;
	}
	
	public static int parseOperater(String requestOperator){
		int type=-1;
		if(requestOperator.equalsIgnoreCase("chinamobile")){
			type= SIM_CHINA_MOBILE;
		}else if(requestOperator.equalsIgnoreCase("chinaunicom")){
			type =SIM_CHINA_UNICOM;
		}else if(requestOperator.equalsIgnoreCase("chinatele")){
			type = SIM_CHINA_TELE;
		}else{
			type = SIM_CHINA_UNKNOWN;
		}
		return type;
	}
	
}
