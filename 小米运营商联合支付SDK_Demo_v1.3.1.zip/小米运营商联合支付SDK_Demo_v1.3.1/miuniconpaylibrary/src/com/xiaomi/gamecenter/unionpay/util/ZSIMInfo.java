package com.xiaomi.gamecenter.unionpay.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;


public class ZSIMInfo
{

	public ZSIMInfo()
	{

	}

	public static String getIMSI( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		return tm.getSubscriberId();
	}

	// imei
	public static String getDeviceID( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		return tm.getDeviceId();
	}

	public static int getSIMState( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		return tm.getSimState();
	}

	// 串号
	public static String getSIMNumber( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		return tm.getSimSerialNumber();
	}

	// 运营商名称
	public static String getSIMOperatorName( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		return tm.getSimOperatorName();
	}

	// 网络制式
	public static String getPhoneType( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		int type = tm.getPhoneType();
		if ( type == TelephonyManager.PHONE_TYPE_GSM )
		{
			return "GSM";
		}
		else if ( type == 2 )
		{
			return "CDMA";
		}
		else
		{
			return "未知";
		}
	}

	// 运营商
	public static String getSIMOperator( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		String operator = tm.getSimOperator();
		if ( "46000".equals( operator ) || "46002".equals( operator ) || "45412".equals( operator ) || "46007".equals( operator ) )
		{
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_CMCC);
			return "中国移动";
		}
		else if ( "46001".equals( operator ) )
		{
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_UNICOM);
			return "中国联通";
		}
		else if ( "46003".equals( operator ) )
		{
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_UNICOM);
			return "中国电信";
		}
		else
		{

			return "未知";
		}
	}

	// 运营商
	public static String getSIMOperatorEnName( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		String operator = tm.getSimOperator();
		if ( "46000".equals( operator ) || "46002".equals( operator ) || "45412".equals( operator ) || "46007".equals( operator ) )
		{
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_CMCC);
			return "CMCC";
		}
		else if ( "46001".equals( operator ) || "46006".equals( operator ) )
		{
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_UNICOM);
			return "UNICOM";
		}
		else if ( "46003".equals( operator ) )
		{
			// QPreference.getInstance().setPreference(QProDefine.T_SENDER,
			// QProDefine.SENDER_UNICOM);
			return "TELECOM";
		}
		else
		{

			return "UNKNOW";
		}
	}

	// 国家
	public static String getSIMCountryIso( Context context )
	{
		TelephonyManager tm = (TelephonyManager) context.getSystemService( Context.TELEPHONY_SERVICE );
		return tm.getSimCountryIso();
	}

	/**
	 * 通过遍历文件夹 来获取3gMAc地址 有可能获取不到 非Wifi状态 需要获取3gMac
	 * 
	 * @return
	 */
	public static String get3gMacAddress( Context context )
	{
		String _3gmac = null;
		WifiManager wifi = (WifiManager) context.getSystemService( Context.WIFI_SERVICE );
		if ( wifi != null && wifi.isWifiEnabled() )
		{
			_3gmac = "";
		}
		else
		{
			try
			{
				File dir = new File( "/sys/class/net/" );
				File file[] = dir.listFiles();
				FileInputStream fip = null;
				int index = -1;
				for ( int i = 0; i < file.length; i++ )
				{
					if ( file[i].isDirectory() && !file[i].getName().equalsIgnoreCase( "lo" ) )
					{
						try
						{
							fip = new FileInputStream( file[i].getPath() + "/carrier" );
							fip.read();// 只要可读 那么该目录即是当前的活动的网络
						}
						catch ( Exception e )
						{
							// e.printStackTrace();
							continue;
						}
						finally
						{
							if ( fip != null )
							{
								try
								{
									fip.close();
								}
								catch ( IOException e )
								{
									// e.printStackTrace();
								}
								fip = null;
							}
						}

						index = i;
						break;
					}
				}

				if ( -1 != index )
				{
					try
					{
						fip = new FileInputStream( "/sys/class/net/" + file[index].getName() + "/address" );
						int len = fip.available();
						if ( len > 0 )
						{
							byte[] buffer = new byte[len];
							fip.read( buffer );
							_3gmac = new String( buffer );
							buffer = null;
							int pos = _3gmac.indexOf( "\n" );// 去掉换行符
							if ( pos != -1 )
							{
								_3gmac = _3gmac.substring( 0, pos );
								if ( 0 == _3gmac.length() )
								{
									_3gmac = null;
								}
							}
						}
					}
					catch ( Exception e )
					{
						// e.printStackTrace();
					}
					finally
					{
						if ( fip != null )
						{
							try
							{
								fip.close();
							}
							catch ( IOException e )
							{
								// e.printStackTrace();
							}
							fip = null;
						}
					}
				}

				return upperCase( _3gmac );
			}
			catch ( Exception e )
			{
				// e.printStackTrace();
			}
		}
		return null;
	}

	private static String upperCase( String s )
	{
		return s.replace( ":", "" ).toUpperCase();
	}

	/**
	 * 获取Mac Address
	 * 
	 * @param go
	 * @return
	 */
	public static String getMacAddress( Context context )
	{
		String macAddress = null;
		WifiManager wifi = (WifiManager) context.getSystemService( Context.WIFI_SERVICE );
		if ( wifi != null )
		{
			WifiInfo info = wifi.getConnectionInfo();
			if ( info != null )
			{
				macAddress = info.getMacAddress();
				if ( macAddress != null )
				{
					return upperCase( macAddress );
				}
			}
		}
		return null;
	}
	
	public static String getMacAddressNew( Context context )
	{
		String macAddress = null;
		WifiManager wifi = (WifiManager) context.getSystemService( Context.WIFI_SERVICE );
		if ( wifi != null )
		{
			WifiInfo info = wifi.getConnectionInfo();
			if ( info != null )
			{
				macAddress = info.getMacAddress();
				if ( macAddress != null )
				{
					return macAddress;
				}
			}
		}
		return null;
	}

	public static String getSha1DeviceID( Context context )
	{
		return SHA1( getDeviceID( context ) );
	}
	public static String SHA1( String plain )
	{
		try
		{
			MessageDigest md = MessageDigest.getInstance( "SHA1" );
			return android.util.Base64.encodeToString( md.digest( plain.getBytes() ), android.util.Base64.URL_SAFE ).substring( 0, 16 );
		}
		catch ( NoSuchAlgorithmException e )
		{
			e.printStackTrace();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		return "";
	}
//	public static String getSha1Mac( Context context )
//	{
//		return SocketTouch.SHA1( getMacAddress( context ) );
//	}
//
//	public static String getSha13gMac( Context context )
//	{
//		return SocketTouch.SHA1( get3gMacAddress( context ) );
//	}
}
